# DUNON — a hillfort in Gaul, 58 BCE

A first-person Three.js explorable environment: a Gaulish hillfort (*oppidum*)
at dusk in late summer, the year Caesar's legions are on the move. This is the
**environment foundation for a game** — no quests, no combat, no dialogue
trees. Walk the ramparts, warm your hands at the hearth fires, inspect five
storytelling POIs, and mind the druid's grove after dark.

## Launch

Serve over HTTP (ES modules + GLB loading require it):

```bash
cd gaulish-hillfort
python3 -m http.server 8000
# open http://localhost:8000
```

Click **WALK IN** — this starts the procedural audio (browser autoplay policy)
and captures the mouse. ESC releases the pointer.

## Controls

| Key | Action |
|-----|--------|
| W A S D / arrows | walk |
| Mouse | look |
| Shift | run |
| E | inspect (5 POIs: rampart, hearth, stone circle, grave, trader cart) |
| M | mute |

## The place

Spawn on the approach road south of the fort, facing the gate — ramparts,
gatehouse torches, and campfire smoke against the dusk sky.

- **Approach road** — dirt track with wheel ruts from the treeline to the gate,
  flanked by crop fields; a trader's cart loaded with amphorae (one banded in
  Roman red) and a traveler's campfire.
- **Murus gallicus** — elliptical rampart (rx≈48m, rz≈42m) of dry stone pinned
  through with a lattice of oak beams, the signature look. Climb the earthen
  ramp by the gate to walk the wall-top with its railing.
- **Gatehouse** — twin timber towers, fighting platform, braziers, torches.
- **Village street** — 7 wattle-and-daub roundhouses with thatch cones; two
  are enterable (one with a fire pit, one lived-in with benches, pots, stores).
- **Feasting hall** — 15m timber longhouse, central hearth, long benches.
- **Forge** — open shelter with procedural anvil, quench barrel, weapon rack
  (spear, sword, round shield, Celtic golden shield), workbench.
- **Druid grove** — old moss-hung oaks, eight standing stones, altar slab,
  heavy drifting mist.
- **Livestock pens** — post-and-rail pens with 3 sheep, 2 cattle, 1 pig
  (idle animations looping), mud churned underfoot.
- **Watchtower** — 9m timber tower by the gate.
- **Fresh grave** — mound, wooden marker, offering pot, near the grove.

Audio is fully procedural WebAudio: wind bed, zone crossfades (9 zones),
fire crackle by proximity, forge hammer clanks, a distant dog, grove crows,
dusk crickets in the fields.

## Tech notes

- Three.js r160 vendored (`js/vendor/`); importmap maps only `three`.
  GLTFLoader's relative `../utils/BufferGeometryUtils.js` import is preserved.
- Seeded procedural canvas textures (thatch, timber, wattle-and-daub,
  rampart stone, mud, grass, dirt road, crop rows, 3-frame flame strip,
  smoke, mist, charred wood) plus a procedural dusk sky (equirect gradient
  with sun glow matched to the directional light) for background + PMREM
  environment.
- One directional (shadow-casting, 2048) + hemisphere + ambient; exactly
  **8 point lights** (hall hearth, forge, roundhouse pit, 3 cookfires,
  2 braziers) — all others are unlit flame sprites. No postprocessing.
- Player: 1.65m eye, 3.2/5.2 m/s, exponential velocity, axis-separated swept
  AABB vs Box3 with 0.15m substeps; feet ride an analytic ground-height
  field (terrain + earthen ramp + wall-top walkway).
- Debug hook: `window.__gaul = {player, world, interactions, ambience,
  camera, scene, teleport(x,z,yaw,pitch), look(yaw,pitch), getState(),
  version:'gaul-1'}`.
- `screenshots/` holds 5 verification views (spawn dusk, village street,
  grove, trader cart, gate approach) captured in headless Chromium.

## Asset licenses

Every third-party asset is **CC0 1.0 Universal** (public domain). The full
per-asset log with source URLs lives in `ASSET_LICENSES.md` in this folder.
Assets actually used in this build:

| Asset | Source |
|-------|--------|
| Kenney nature-kit GLBs (oaks, pines, rocks, grass, bushes, flowers, firewood, log stack, hanging moss, stumps) | https://kenney.nl/assets/nature-kit |
| Kenney pirate-kit GLBs (barrel, crate, fence crosses) | https://kenney.nl/assets/pirate-kit |
| Quaternius farm animals (Cow, Sheep, Pig — FBX→GLB via Blender) | quaternius.com via beep2bleep/FreeAssetsByKenneyNLandQuaternius mirror |
| Quaternius medieval weapons (Spear, Sword, Shield_Round, Shield_Celtic_Golden — FBX→GLB via Blender) | quaternius.com via same mirror |
| Quaternius background characters (Male_Standing, Female_Standing, Female_Sitting — FBX→GLB via Blender) | quaternius.com via same mirror |

The Blender FBX→GLB conversions remain CC0 (format shift only, no new
authorship). Note: the pirate-kit GLBs reference `Textures/colormap.png`,
which was not shipped with the vendored files — this build includes a
procedurally generated wood-tone stand-in at
`assets/props/Textures/colormap.png` so the props load and read as timber.

## Honest limitations

- Verified in headless Chromium (SwiftShader) after construction: scene
  loads with zero console errors/warnings; teleports, terrain-following,
  zone tracking, WASD movement (3.0 m/s walk / 5.1 m/s sprint measured),
  gate-passage walk, and all five POI prompts behave; prompt raycasts are
  occlusion-tested against wall colliders (no inspecting through walls).
  Two verifier critique cycles fixed: the photo sky (replaced with a
  procedural dusk), floating cyan moss shards (recolored, shrunk, tucked
  into the oak crowns), teal grass tufts, and the prompt-through-wall bug.
- Kenney vegetation uses `KHR_materials_unlit` — trees render as flat dusk
  silhouettes (materials dimmed 10–18% to sit in the light). Deliberate.
- Fire/prop placement, animal positions, and tree scattering are seeded and
  deterministic, but were tuned blind — sightlines may want a nudge after
  screenshots.
- Audio and frame-rate figures are unverified (no audio device / GPU in the
  build VM); gains are conservative by construction.
- The rampart walkway covers the south arc only; the rest of the wall top is
  not walkable. The watchtower platform is not climbable (visual ladder).
- POI text is atmospheric and roughly-right history, not scholarship.
