# Asset Licenses — Gaulish Hillfort (~58 BCE)

Every file below is **CC0 1.0 Universal (public domain)**. No attribution is legally required;
credits are recorded anyway as a courtesy. No CC-BY / CC-BY-NC / CC-BY-SA assets were used.
Files live in `assets/<category>/`. Total: 50 files.

## Provenance notes
- Kenney assets: downloaded from kenney.nl (site-wide CC0). Kenney's License.txt (shipped in each kit) confirms CC0 1.0 Universal.
- Quaternius assets: CC0 1.0 Universal per quaternius.com license. Files pulled from the community mirror
  `beep2bleep/FreeAssetsByKenneyNLandQuaternius` (master branch), whose `License.txt` re-states the CC0 1.0
  dedication; official pack pages: https://quaternius.com/packs. Each entry below carries the exact raw file URL.
- Poly Haven HDRIs: CC0 1.0 per https://polyhaven.com/license, fetched via the public API with a Referer header.

## trees (11 files)

### `trees/tree_oak.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~196 tris | Animated: no

### `trees/tree_oak_dark.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~196 tris | Animated: no

### `trees/tree_detailed.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~402 tris | Animated: no

### `trees/tree_tall.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~72 tris | Animated: no

### `trees/tree_fat.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~50 tris | Animated: no

### `trees/tree_pineTallA_detailed.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~134 tris | Animated: no

### `trees/tree_pineTallB_detailed.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~166 tris | Animated: no

### `trees/tree_pineDefaultA.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~230 tris | Animated: no

### `trees/tree_pineRoundA.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~204 tris | Animated: no

### `trees/stump_old.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~120 tris | Animated: no

### `trees/hanging_moss.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~52 tris | Animated: no

## nature (18 files)

### `nature/rock_largeA.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~80 tris | Animated: no

### `nature/rock_largeB.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~85 tris | Animated: no

### `nature/rock_smallA.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~16 tris | Animated: no

### `nature/rock_smallB.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~24 tris | Animated: no

### `nature/rock_tallA.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~136 tris | Animated: no

### `nature/grass.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~132 tris | Animated: no

### `nature/grass_large.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~224 tris | Animated: no

### `nature/grass_leafs.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~36 tris | Animated: no

### `nature/plant_bush.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~32 tris | Animated: no

### `nature/plant_bushDetailed.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~104 tris | Animated: no

### `nature/plant_bushLarge.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~60 tris | Animated: no

### `nature/plant_bushSmall.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~16 tris | Animated: no

### `nature/flower_redA.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~76 tris | Animated: no

### `nature/flower_yellowA.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~76 tris | Animated: no

### `nature/flower_purpleA.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~76 tris | Animated: no

### `nature/mushroom_red.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~48 tris | Animated: no

### `nature/mushroom_tan.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~48 tris | Animated: no

### `nature/stump_round.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~56 tris | Animated: no

## animals (4 files)

### `animals/Cow.fbx`
- License: CC0 1.0 Universal
- Source: https://raw.githubusercontent.com/beep2bleep/FreeAssetsByKenneyNLandQuaternius/master/FreeModels%20by%20Quaternius%5BPatreon%5D/Characters%20and%20Animals/Farm%20Animals%20Animated%20%20-%20Jun%202018/FBX/Cow.fbx
- Credit: Quaternius — CC0, no attribution required (official pack: https://quaternius.com/packs)
- Geometry: n/a (FBX/HDR) | Animated: yes

### `animals/Sheep.fbx`
- License: CC0 1.0 Universal
- Source: https://raw.githubusercontent.com/beep2bleep/FreeAssetsByKenneyNLandQuaternius/master/FreeModels%20by%20Quaternius%5BPatreon%5D/Characters%20and%20Animals/Farm%20Animals%20Animated%20%20-%20Jun%202018/FBX/Sheep.fbx
- Credit: Quaternius — CC0, no attribution required (official pack: https://quaternius.com/packs)
- Geometry: n/a (FBX/HDR) | Animated: yes

### `animals/Pig.fbx`
- License: CC0 1.0 Universal
- Source: https://raw.githubusercontent.com/beep2bleep/FreeAssetsByKenneyNLandQuaternius/master/FreeModels%20by%20Quaternius%5BPatreon%5D/Characters%20and%20Animals/Farm%20Animals%20Animated%20%20-%20Jun%202018/FBX/Pig.fbx
- Credit: Quaternius — CC0, no attribution required (official pack: https://quaternius.com/packs)
- Geometry: n/a (FBX/HDR) | Animated: yes

### `animals/Horse.fbx`
- License: CC0 1.0 Universal
- Source: https://raw.githubusercontent.com/beep2bleep/FreeAssetsByKenneyNLandQuaternius/master/FreeModels%20by%20Quaternius%5BPatreon%5D/Characters%20and%20Animals/Farm%20Animals%20Animated%20%20-%20Jun%202018/FBX/Horse.fbx
- Credit: Quaternius — CC0, no attribution required (official pack: https://quaternius.com/packs)
- Geometry: n/a (FBX/HDR) | Animated: yes

## props (7 files)

### `props/barrel.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/pirate-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~148 tris | Animated: no

### `props/crate.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/pirate-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~76 tris | Animated: no

### `props/chest.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/pirate-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~232 tris | Animated: no

### `props/structure-fence.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/pirate-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~356 tris | Animated: no

### `props/structure-fence-sides.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/pirate-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~436 tris | Animated: no

### `props/firewood_pile.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required (renamed from campfire_logs.glb)
- Geometry: ~112 tris | Animated: no

### `props/log_stack.glb`
- License: CC0 1.0 Universal
- Source: https://kenney.nl/assets/nature-kit
- Credit: Kenney (kenney.nl) — no attribution required
- Geometry: ~184 tris | Animated: no

## weapons (4 files)

### `weapons/Spear.fbx`
- License: CC0 1.0 Universal
- Source: https://raw.githubusercontent.com/beep2bleep/FreeAssetsByKenneyNLandQuaternius/master/FreeModels%20by%20Quaternius%5BPatreon%5D/Medieval/Medieval%20Weapons%20Pack%20-%20Sept%202018/FBX/Spear.fbx
- Credit: Quaternius — CC0, no attribution required (official pack: https://quaternius.com/packs)
- Geometry: n/a (FBX/HDR) | Animated: no

### `weapons/Shield_Round.fbx`
- License: CC0 1.0 Universal
- Source: https://raw.githubusercontent.com/beep2bleep/FreeAssetsByKenneyNLandQuaternius/master/FreeModels%20by%20Quaternius%5BPatreon%5D/Medieval/Medieval%20Weapons%20Pack%20-%20Sept%202018/FBX/Shield_Round.fbx
- Credit: Quaternius — CC0, no attribution required (official pack: https://quaternius.com/packs)
- Geometry: n/a (FBX/HDR) | Animated: no

### `weapons/Shield_Celtic_Golden.fbx`
- License: CC0 1.0 Universal
- Source: https://raw.githubusercontent.com/beep2bleep/FreeAssetsByKenneyNLandQuaternius/master/FreeModels%20by%20Quaternius%5BPatreon%5D/Medieval/Medieval%20Weapons%20Pack%20-%20Sept%202018/FBX/Shield_Celtic_Golden.fbx
- Credit: Quaternius — CC0, no attribution required (official pack: https://quaternius.com/packs)
- Geometry: n/a (FBX/HDR) | Animated: no

### `weapons/Sword.fbx`
- License: CC0 1.0 Universal
- Source: https://raw.githubusercontent.com/beep2bleep/FreeAssetsByKenneyNLandQuaternius/master/FreeModels%20by%20Quaternius%5BPatreon%5D/Medieval/Medieval%20Weapons%20Pack%20-%20Sept%202018/FBX/Sword.fbx
- Credit: Quaternius — CC0, no attribution required (official pack: https://quaternius.com/packs)
- Geometry: n/a (FBX/HDR) | Animated: no

## characters (4 files)

### `characters/Male_Standing.fbx`
- License: CC0 1.0 Universal
- Source: https://raw.githubusercontent.com/beep2bleep/FreeAssetsByKenneyNLandQuaternius/master/FreeModels%20by%20Quaternius%5BPatreon%5D/Characters%20and%20Animals/Posed%20Background%20Characters%20-%20Aug%202018/Male/Male%20Poses/FBX/Male_Standing.fbx
- Credit: Quaternius — CC0, no attribution required (official pack: https://quaternius.com/packs)
- Geometry: n/a (FBX/HDR) | Animated: no

### `characters/Male_Walking.fbx`
- License: CC0 1.0 Universal
- Source: https://raw.githubusercontent.com/beep2bleep/FreeAssetsByKenneyNLandQuaternius/master/FreeModels%20by%20Quaternius%5BPatreon%5D/Characters%20and%20Animals/Posed%20Background%20Characters%20-%20Aug%202018/Male/Male%20Poses/FBX/Male_Walking.fbx
- Credit: Quaternius — CC0, no attribution required (official pack: https://quaternius.com/packs)
- Geometry: n/a (FBX/HDR) | Animated: no

### `characters/Female_Standing.fbx`
- License: CC0 1.0 Universal
- Source: https://raw.githubusercontent.com/beep2bleep/FreeAssetsByKenneyNLandQuaternius/master/FreeModels%20by%20Quaternius%5BPatreon%5D/Characters%20and%20Animals/Posed%20Background%20Characters%20-%20Aug%202018/Female/Female%20Poses/FBX/Female_Standing.fbx
- Credit: Quaternius — CC0, no attribution required (official pack: https://quaternius.com/packs)
- Geometry: n/a (FBX/HDR) | Animated: no

### `characters/Female_Sitting.fbx`
- License: CC0 1.0 Universal
- Source: https://raw.githubusercontent.com/beep2bleep/FreeAssetsByKenneyNLandQuaternius/master/FreeModels%20by%20Quaternius%5BPatreon%5D/Characters%20and%20Animals/Posed%20Background%20Characters%20-%20Aug%202018/Female/Female%20Poses/FBX/Female_Sitting.fbx
- Credit: Quaternius — CC0, no attribution required (official pack: https://quaternius.com/packs)
- Geometry: n/a (FBX/HDR) | Animated: no

## sky

No sky image assets — the dusk sky is fully procedural (`duskSky()` in
`js/textures.js`). Two Poly Haven HDRIs were evaluated during construction
and removed before release.
