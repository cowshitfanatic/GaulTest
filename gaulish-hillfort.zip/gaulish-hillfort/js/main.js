import * as THREE from 'three';
import { buildWorld } from './world.js';
import { Player } from './player.js';
import { Interactions } from './interactions.js';
import { Ambience } from './audio.js';

const $ = (id) => document.getElementById(id);
const loadFill = $('loadFill'), loadMsg = $('loadMsg');
function progress(pct, msg) { loadFill.style.width = (pct * 100).toFixed(0) + '%'; if (msg) loadMsg.textContent = msg; }
function phase(msg) { loadMsg.textContent = msg; }
const tick = () => new Promise(r => setTimeout(r, 16));

function fatal(msg) {
  $('loader').classList.add('done');
  $('starter').classList.add('hidden');
  $('errbox').classList.remove('hidden');
  if (msg) $('errMsg').textContent = msg;
}
window.addEventListener('error', (e) => {
  if ($('errbox').classList.contains('hidden') === false) return;
  if (window.__gaul) { console.error(e.error || e.message); return; } // already running: log, don't kill
  fatal('Error: ' + (e.message || 'failed to start'));
});

let renderer, scene, camera, world, player, interactions, ambience;
let currentZone = 'approach';

function toast(text, ms = 2600) {
  const el = $('toast'); el.textContent = text; el.style.opacity = 1;
  clearTimeout(toast._t); toast._t = setTimeout(() => el.style.opacity = 0, ms);
}

async function init() {
  progress(0.04, 'surveying the hill…'); await tick();
  const manager = new THREE.LoadingManager();
  manager.onProgress = (url, loaded, total) => {
    progress(0.12 + 0.68 * (loaded / Math.max(1, total)));
  };
  manager.onError = (url) => {
    fatal('A required asset failed to load (' + String(url).split('/').pop() + ').');
  };

  try {
    renderer = new THREE.WebGLRenderer({ canvas: $('scene'), antialias: true, powerPreference: 'high-performance' });
  } catch (e) { fatal('WebGL is unavailable in this browser.'); return; }
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.12;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);

  progress(0.10, 'letting the dusk in…'); await tick();
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 0.05, 500);
  camera.rotation.order = 'YXZ';
  scene.add(camera);

  try {
    world = await buildWorld(scene, manager, phase, renderer);
  } catch (e) {
    console.error(e);
    fatal('The hillfort failed to rise: ' + (e.message || e));
    return;
  }

  progress(0.86, 'waking the player…'); await tick();
  player = new Player(camera, renderer.domElement, () => world.colliders, (x, z) => world.groundHeight(x, z));
  player.teleport(world.spawn.pos, world.spawn.yaw);

  ambience = new Ambience();
  interactions = new Interactions(camera, renderer.domElement, () => world.interactables, {
    promptEl: $('prompt')
  }, {
    occluders: world.colliders,
    onToggleFlashlight: () => toast('No torch needed — the dusk is light enough', 1800),
    onToggleMute: () => toast(ambience.toggleMute() ? 'SOUND MUTED' : 'SOUND ON', 1200),
    onObjectiveEvent: () => {}
  });

  // debug / verification hooks (used by headless walkthrough)
  window.__gaul = {
    player, world, interactions, ambience, camera, scene,
    teleport: (x, z, yaw = 0, pitch = 0) => {
      player.pitch = THREE.MathUtils.clamp(pitch, -1.2, 1.2);
      player.teleport(new THREE.Vector3(x, 0, z), yaw);
    },
    look: (yaw, pitch) => {
      player.yaw = yaw;
      player.pitch = THREE.MathUtils.clamp(pitch, -1.2, 1.2);
      player._applyLook();
    },
    getState: () => ({ zone: currentZone, pos: player.getPosition().toArray() }),
    version: 'gaul-1'
  };

  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  progress(0.95, 'sweeping the threshold…'); await tick();
  progress(1, 'ready'); await tick();
  $('loader').classList.add('done');
  $('starter').classList.remove('hidden');

  $('enterBtn').addEventListener('click', (e) => {
    e.stopPropagation();
    ambience.start();
    $('starter').classList.add('hidden');
    player.requestLock();
    toast('WASD MOVE · MOUSE LOOK · E INSPECT', 3400);
  });
  // clicking anywhere on starter also enters (button is the clear CTA)
  $('starter').addEventListener('click', () => $('enterBtn').click());

  renderer.setAnimationLoop(loop);
}

const clock = new THREE.Clock();
const WORLD_EDGE = 126; // invisible boundary at the wildwood's heart
function loop() {
  const dt = Math.min(clock.getDelta(), 0.05);
  const t = clock.elapsedTime;

  player.update(dt);
  // keep the player inside the world
  const pp = player.pos, rr = Math.hypot(pp.x, pp.z);
  if (rr > WORLD_EDGE) { pp.x *= WORLD_EDGE / rr; pp.z *= WORLD_EDGE / rr; }

  world.update(dt, t);
  interactions.update(dt);

  // zone tracking -> ambience
  const p = player.getPosition();
  const z = world.zoneAt(p.x, p.z, player.pos.y);
  if (z !== currentZone) { currentZone = z; ambience.setZone(z); }
  ambience.setFireDist(world.nearestFireDist(p.x, p.z));
  ambience.setForgeNear(p.distanceTo(world.forgePos) < 11);

  renderer.render(scene, camera);
}

init();
