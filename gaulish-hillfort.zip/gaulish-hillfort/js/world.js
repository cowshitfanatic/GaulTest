// World builder — Dunon, a hillfort in Gaul (~58 BCE, late summer, dusk).
// buildWorld(scene, manager, phase, renderer) -> { colliders, spawn, interactables, zones,
//   update, onEvent, groundHeight, nearestFireDist, forgePos }
//
// Layout (meters, y-up, origin = fort center):
//   approach road (0,110)->gate(0,42); rampart ellipse rx=48 rz=42;
//   village street gate->(0,-10); 7 roundhouses; feasting hall (18,-5);
//   forge (-16,8); druid grove (-28,-25); pens (28,-20); watchtower (10,36);
//   fields S/E; forest ring r>70; trader cart (6,70); grave (-22,-31).
import * as THREE from 'three';
import { GLTFLoader } from './vendor/loaders/GLTFLoader.js';
import {
  thatch, timber, wattleDaub, stoneWall, mudGround, grassGround,
  dirtRoad, cropRows, flameStrip, smoke, mist, charred, duskSky
} from './textures.js';

/* ---------------- deterministic rng + value noise (terrain) ---------------- */

function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function makeNoise2D(seed) {
  const rand = mulberry32(seed);
  const p = Array.from({ length: 256 }, (_, i) => i);
  for (let i = 255; i > 0; i--) { const j = (rand() * (i + 1)) | 0; [p[i], p[j]] = [p[j], p[i]]; }
  const P = new Uint8Array(512);
  for (let i = 0; i < 512; i++) P[i] = p[i & 255];
  const val = (ix, iy) => P[(P[ix & 255] + iy) & 255] / 255;
  const fade = t => t * t * (3 - 2 * t);
  return (x, y) => {
    const ix = Math.floor(x), iy = Math.floor(y);
    const fx = x - ix, fy = y - iy;
    const a = val(ix, iy), b = val(ix + 1, iy), c = val(ix, iy + 1), d = val(ix + 1, iy + 1);
    const u = fade(fx), v = fade(fy);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  };
}
function fbm2(n, x, y, oct = 4) {
  let amp = 0.5, f = 1, s = 0, norm = 0;
  for (let i = 0; i < oct; i++) { s += amp * n(x * f, y * f); norm += amp; amp *= 0.5; f *= 2; }
  return s / norm;
}
const smoothstep = (a, b, x) => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};

/* ---------------- terrain height field ---------------- */

const TN = makeNoise2D(4242);

// Flattened pads under structures: {x, z, r} — target height resolved at build.
const PADS = [
  { x: 0, z: 42, r: 13 },                 // gate
  { x: 0, z: 30, r: 10 }, { x: 0, z: 16, r: 10 }, { x: 0, z: 2, r: 10 }, // street
  { x: 18, z: -5, r: 12 },                // hall
  { x: -16, z: 8, r: 10 },                // forge
  { x: -28, z: -25, r: 13 },              // grove
  { x: 29, z: -20, r: 14 },               // pens
  { x: 10, z: 36, r: 7 },                 // watchtower
  { x: 6, z: 70, r: 8 },                  // trader cart
  { x: -14, z: 22, r: 7 }, { x: 13, z: 18, r: 7 }, { x: -17, z: 8, r: 7 },
  { x: 16, z: 4, r: 7 }, { x: -13, z: -2, r: 7 }, { x: 15, z: -8, r: 7 },
  { x: -16, z: -12, r: 7 },               // roundhouses
  { x: -22, z: -31, r: 6 },               // grave
];
function terrainBase(x, z) {
  const r = Math.hypot(x, z);
  // gentle hill the dunon sits on, ~3.5m of rise, plus rolling noise
  const hill = 3.6 * Math.exp(-(r * r) / (2 * 58 * 58));
  const roll = (fbm2(TN, x * 0.02, z * 0.02) - 0.5) * 2.4;
  const detail = (fbm2(TN, x * 0.09 + 31, z * 0.09) - 0.5) * 0.7;
  return hill + roll + detail;
}
for (const p of PADS) p.h = terrainBase(p.x, p.z);
function terrainHeight(x, z) {
  let h = terrainBase(x, z);
  for (const p of PADS) {
    const d = Math.hypot(x - p.x, z - p.z);
    if (d < p.r) {
      const t = 1 - d / p.r;
      const s = smoothstep(0.35, 0.85, t);
      h = h + (p.h - h) * s;
    }
  }
  return h;
}

// Rampart walk overrides (earthen ramp + wall-top walkway, y=3 above local ground)
const RAMP = { x1: -12, x2: -6, z1: 36.8, z2: 39.4 };
const WALL_RX = 48, WALL_RZ = 42, WALL_H = 3, WALL_T = 4;
function ellipseDist(x, z) {
  const th = Math.atan2(z / WALL_RZ, x / WALL_RX);
  const ex = WALL_RX * Math.cos(th), ez = WALL_RZ * Math.sin(th);
  return { d: Math.hypot(x - ex, z - ez) };
}
function groundHeight(x, z) {
  // earthen ramp up to the walkway
  if (x >= RAMP.x1 && x <= RAMP.x2 && z >= RAMP.z1 && z <= RAMP.z2) {
    const t = (z - RAMP.z1) / (RAMP.z2 - RAMP.z1);
    return terrainHeight(x, z) * (1 - t) + (terrainHeight(x, RAMP.z2) + WALL_H) * t;
  }
  // wall-top walkway: south arc near the gate, outside the gate opening
  if (z > 30 && Math.abs(x) > 6.8 && Math.abs(x) < 17 && ellipseDist(x, z).d < 2.2) {
    return terrainHeight(x, z) + WALL_H + 0.15;
  }
  return terrainHeight(x, z);
}

/* ================= buildWorld ================= */

export async function buildWorld(scene, manager, phase, renderer) {
  const colliders = [];
  const interactables = [];
  const listeners = [];
  const emit = (n) => listeners.forEach(cb => { try { cb(n); } catch (e) {} });
  const onEvent = (cb) => listeners.push(cb);
  const rng = mulberry32(777);

  const loader = new GLTFLoader(manager);
  const texLoader = new THREE.TextureLoader(manager);
  const loadGlb = (path) => loader.loadAsync(path);

  /* ---------------- shared textures / materials ---------------- */
  const rep = (t, rx, ry) => { const c = t.clone(); c.repeat.set(rx, ry); c.needsUpdate = true; return c; };
  const std = (map, o = {}) => new THREE.MeshStandardMaterial(Object.assign({ map, roughness: 0.92, metalness: 0.02 }, o));
  const T = {
    thatch: thatch(), timber: timber(), timberDark: timber('#4e3a24'),
    daub: wattleDaub(), stone: stoneWall(), mud: mudGround(), mudDark: mudGround('#4a3826'),
    grass: grassGround(), road: dirtRoad(), crops: cropRows(),
    flame: flameStrip(), smoke: smoke(), mist: mist(), char: charred(),
  };
  const M = {
    thatch: std(T.thatch, { roughness: 0.95 }),
    timber: std(T.timber, { roughness: 0.85 }),
    timberDark: std(T.timberDark, { roughness: 0.9 }),
    daub: std(T.daub, { roughness: 0.95 }),
    stone: std(T.stone, { roughness: 0.95 }),
    mud: std(T.mud, { roughness: 0.98 }),
    mudDark: std(T.mudDark, { roughness: 0.98 }),
    grass: std(T.grass, { roughness: 0.95, vertexColors: true }),
    char: std(T.char, { roughness: 0.9 }),
    ironDark: new THREE.MeshStandardMaterial({ color: 0x2e2c2a, roughness: 0.55, metalness: 0.75 }),
    bronze: new THREE.MeshStandardMaterial({ color: 0x8a6a2e, roughness: 0.4, metalness: 0.8 }),
    red: new THREE.MeshStandardMaterial({ color: 0x8a2a1e, roughness: 0.7 }),
    clay: std(null, { color: 0x9a6a42, roughness: 0.9 }),
  };
  const proxyMat = new THREE.MeshBasicMaterial({ visible: false });

  /* ---------------- small builders ---------------- */
  function box(w, h, d, material, x, y, z, o = {}) {
    const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
    m.position.set(x, y, z);
    if (o.ry) m.rotation.y = o.ry;
    if (o.rx) m.rotation.x = o.rx;
    if (o.rz) m.rotation.z = o.rz;
    m.castShadow = !!o.cast; m.receiveShadow = o.recv !== false;
    (o.parent || scene).add(m);
    return m;
  }
  function solid(x1, z1, x2, z2, h = 3.0, y0 = -3) {
    const b = new THREE.Box3(new THREE.Vector3(x1, y0, z1), new THREE.Vector3(x2, y0 + h, z2));
    colliders.push(b); return b;
  }
  function solidAt(x, z, w, d, h, y0 = -3) {
    return solid(x - w / 2, z - d / 2, x + w / 2, z + d / 2, h, y0);
  }
  // place an Object3D/Group so its base sits on the terrain
  function sit(obj, x, z, dy = 0) { obj.position.set(x, terrainHeight(x, z) + dy, z); scene.add(obj); return obj; }

  /* ---------------- terrain ---------------- */
  phase('surveying the hill…');
  {
    const SIZE = 260, SEG = 110;
    const g = new THREE.PlaneGeometry(SIZE, SIZE, SEG, SEG);
    g.rotateX(-Math.PI / 2);
    const pos = g.attributes.position;
    const colors = new Float32Array(pos.count * 3);
    const cMud = new THREE.Color(0x9a7a54), cMudD = new THREE.Color(0x7a5c3e), cWhite = new THREE.Color(0xffffff);
    const tmp = new THREE.Color();
    const mudRects = [
      { x1: -4, z1: -12, x2: 4, z2: 44, c: cMud },      // street
      { x1: 20, z1: -30, x2: 40, z2: -10, c: cMudD },   // pens
      { x1: 8, z1: -13, x2: 28, z2: 3, c: cMud },       // hall yard
      { x1: -24, z1: 2, x2: -8, z2: 14, c: cMud },       // forge yard
    ];
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i), z = pos.getZ(i);
      const h = terrainHeight(x, z);
      pos.setY(i, h);
      tmp.copy(cWhite);
      for (const r of mudRects) {
        if (x >= r.x1 && x <= r.x2 && z >= r.z1 && z <= r.z2) { tmp.copy(r.c); break; }
      }
      colors[i * 3] = tmp.r; colors[i * 3 + 1] = tmp.g; colors[i * 3 + 2] = tmp.b;
    }
    g.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    g.computeVertexNormals();
    const terrain = new THREE.Mesh(g, new THREE.MeshStandardMaterial({
      map: rep(T.grass, 40, 40), roughness: 0.96, metalness: 0, vertexColors: true,
    }));
    terrain.receiveShadow = true;
    scene.add(terrain);
  }

  /* ---------------- dirt roads (ribbons following the terrain) ---------------- */
  function roadRibbon(pts, width) {
    // pts: array of [x,z]; ribbon laid width/2 each side, hugging terrain
    const verts = [], uvs = [], idx = [];
    let dist = 0;
    for (let i = 0; i < pts.length; i++) {
      const [x, z] = pts[i];
      const [px, pz] = pts[Math.max(0, i - 1)], [nx, nz] = pts[Math.min(pts.length - 1, i + 1)];
      let dx = nx - px, dz = nz - pz;
      const l = Math.hypot(dx, dz) || 1; dx /= l; dz /= l;
      if (i > 0) dist += Math.hypot(x - pts[i - 1][0], z - pts[i - 1][1]);
      const ox = -dz * width / 2, oz = dx * width / 2;
      const y1 = terrainHeight(x + ox, z + oz) + 0.07, y2 = terrainHeight(x - ox, z - oz) + 0.07;
      verts.push(x + ox, y1, z + oz, x - ox, y2, z - oz);
      uvs.push(0, dist / 4, 1, dist / 4);
      if (i > 0) { const b = i * 2; idx.push(b - 2, b, b - 1, b - 1, b, b + 1); }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    g.setIndex(idx);
    g.computeVertexNormals();
    const m = new THREE.Mesh(g, new THREE.MeshStandardMaterial({
      map: rep(T.road, 1, 1), roughness: 0.98,
      polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2,
    }));
    m.receiveShadow = true;
    scene.add(m);
    return m;
  }
  phase('wearing the old road…');
  roadRibbon([[0, 112], [0.5, 96], [-0.5, 80], [0.5, 64], [0, 50], [0, 42]], 3.6);
  roadRibbon([[0, 42], [0.4, 30], [-0.4, 18], [0.3, 6], [0, -6], [0, -12]], 3.0);

  /* ---------------- sky, fog, lights ---------------- */
  phase('letting the dusk in…');
  {
    const skyTex = duskSky(); // procedural dusk; the photo sky read as overcast noon
    skyTex.mapping = THREE.EquirectangularReflectionMapping;
    skyTex.colorSpace = THREE.SRGBColorSpace;
    scene.background = skyTex;
    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromEquirectangular(skyTex).texture;
    pmrem.dispose();
  }
  scene.fog = new THREE.FogExp2(0x5a4038, 0.008);

  const sun = new THREE.DirectionalLight(0xff9a4e, 2.6);
  sun.position.set(-70, 15, 28); // low in the west
  sun.castShadow = true;
  sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.camera.left = -75; sun.shadow.camera.right = 75;
  sun.shadow.camera.top = 75; sun.shadow.camera.bottom = -75;
  sun.shadow.camera.near = 10; sun.shadow.camera.far = 220;
  sun.shadow.bias = -0.0008;
  sun.shadow.normalBias = 0.03;
  scene.add(sun);
  scene.add(sun.target);
  const hemi = new THREE.HemisphereLight(0x6a5a8a, 0x3a2c22, 0.7);
  scene.add(hemi);
  const ember = new THREE.AmbientLight(0x2a1e2a, 0.55);
  scene.add(ember);

  /* ---------------- murus gallicus rampart ---------------- */
  phase('raising the ramparts…');
  const SEG_N = 30;
  const gateHalfAngle = 4.2 / WALL_RX; // ~4m opening each side of the gate
  const beamMatrices = [];
  {
    const stoneMat = std(rep(T.stone, 3.2, 1), { roughness: 0.95 });
    const beamGeo = new THREE.BoxGeometry(1, 0.24, 0.24);
    const dummy = new THREE.Object3D();
    for (let i = 0; i < SEG_N; i++) {
      const t0 = (i / SEG_N) * Math.PI * 2, t1 = ((i + 1) / SEG_N) * Math.PI * 2;
      const tm = (t0 + t1) / 2;
      // angular distance to the gate (theta = PI/2)
      let dAng = Math.abs(tm - Math.PI / 2);
      if (dAng > Math.PI) dAng = Math.PI * 2 - dAng;
      if (dAng < gateHalfAngle) continue; // gate opening
      const x0 = WALL_RX * Math.cos(t0), z0 = WALL_RZ * Math.sin(t0);
      const x1 = WALL_RX * Math.cos(t1), z1 = WALL_RZ * Math.sin(t1);
      const cx = (x0 + x1) / 2, cz = (z0 + z1) / 2;
      const len = Math.hypot(x1 - x0, z1 - z0);
      const yaw = Math.atan2(-(z1 - z0), x1 - x0); // tangent heading
      const gy = terrainHeight(cx, cz);
      const seg = box(len, WALL_H, WALL_T, stoneMat, cx, gy + WALL_H / 2, cz, { ry: yaw, cast: true });
      // stone footing skirt
      box(len * 0.99, 0.5, WALL_T + 1.2, std(rep(T.stone, 3, 0.5)), cx, gy + 0.25, cz, { ry: yaw });
      colliders.push(new THREE.Box3().setFromObject(seg));
      // timber lattice: horizontal beams on both faces + vertical posts
      const nx = Math.sin(yaw), nz = Math.cos(yaw); // face normal (approx)
      for (const s of [1, -1]) {
        for (const by of [0.75, 1.55, 2.35]) {
          dummy.position.set(cx + nx * s * (WALL_T / 2 + 0.06), gy + by, cz + nz * s * (WALL_T / 2 + 0.06));
          dummy.rotation.set(0, yaw, 0);
          dummy.scale.set(len * 0.96, 1, 1);
          dummy.updateMatrix();
          beamMatrices.push(dummy.matrix.clone());
        }
        const posts = Math.max(2, Math.round(len / 3.4));
        for (let p = 0; p <= posts; p++) {
          const f = p / posts - 0.5;
          dummy.position.set(
            cx + Math.cos(yaw) * f * len + nx * s * (WALL_T / 2 + 0.02),
            gy + WALL_H / 2,
            cz - Math.sin(yaw) * f * len + nz * s * (WALL_T / 2 + 0.02));
          dummy.rotation.set(0, yaw, 0);
          dummy.scale.set(1, WALL_H / 0.24, 1);
          dummy.updateMatrix();
          beamMatrices.push(dummy.matrix.clone());
        }
      }
    }
    const beams = new THREE.InstancedMesh(beamGeo, M.timberDark, beamMatrices.length);
    beamMatrices.forEach((m, i) => beams.setMatrixAt(i, m));
    beams.instanceMatrix.needsUpdate = true;
    beams.castShadow = true; beams.receiveShadow = true;
    beams.frustumCulled = false;
    scene.add(beams);
  }

  /* ---------------- gatehouse (south) ---------------- */
  const fires = [];   // {x, y, z} — fire registry for lights/sprites/audio
  const flameSprites = [];  // {sprite, tex, phase, scale}
  const smokePuffs = [];    // {sprite, life, x,y,z, seed}
  const fireLights = [];    // {light, base, seed, x, y, z}
  function makeTorch(x, y, z, scale = 0.8) {
    // wall-mounted torch: iron bracket + flame sprite, no light (braziers carry the budget)
    box(0.1, 0.1, 0.5, M.ironDark, x, y - 0.35, z + 0.2, { rx: 0.5 });
    const ftex = T.flame.clone(); ftex.needsUpdate = true;
    ftex.repeat.set(1 / 3, 1);
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: ftex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
    spr.position.set(x, y, z); spr.scale.set(0.9 * scale, 1.25 * scale, 1);
    scene.add(spr);
    flameSprites.push({ sprite: spr, tex: ftex, phase: rng() * 3, scale });
    fires.push({ x, y, z, torch: true });
  }
  {
    const gy = terrainHeight(0, 42);
    for (const sx of [-4.6, 4.6]) {
      const tx = sx, tz = 42;
      const ty = terrainHeight(tx, tz);
      // square timber tower
      box(3.2, 7, 3.2, std(rep(T.timber, 2, 3)), tx, ty + 3.5, tz, { cast: true });
      // corner posts
      for (const [ox, oz] of [[-1.5, -1.5], [1.5, -1.5], [-1.5, 1.5], [1.5, 1.5]])
        box(0.35, 7.6, 0.35, M.timberDark, tx + ox, ty + 3.8, tz + oz, { cast: true });
      // pyramid cap
      const cap = new THREE.Mesh(new THREE.ConeGeometry(2.9, 1.8, 4), M.thatch);
      cap.position.set(tx, ty + 7.9, tz); cap.rotation.y = Math.PI / 4;
      cap.castShadow = true; scene.add(cap);
      // torch on the road-facing tower face
      makeTorch(tx, ty + 5.6, tz - 1.7, 0.85);
      solidAt(tx, tz, 3.4, 3.4, 10, ty - 3);
    }
    // lintel beam + fighting platform over the passage
    box(13.5, 0.5, 3.4, M.timberDark, 0, gy + 5.4, 42, { cast: true });
    box(13.5, 0.25, 3.8, std(rep(T.timber, 6, 1)), 0, gy + 5.75, 42, { cast: true });
    // passage side walls (leave 4m open)
    for (const sx of [-2.75, 2.75]) {
      const wy = terrainHeight(sx, 42);
      box(1.5, 4.2, 7, std(rep(T.stone, 2, 1.4)), sx, wy + 2.1, 42, { cast: true });
      solidAt(sx, 42, 1.5, 7, 7.2, wy - 3);
    }
    // braziers flanking the passage (these carry point lights)
    for (const sx of [-4.5, 4.5]) {
      const by = terrainHeight(sx, 38.5);
      makeBrazier(sx, by, 38.5, true);
    }
  }

  /* ---------------- watchtower (10, 36) ---------------- */
  {
    const tx = 10, tz = 36, ty = terrainHeight(tx, tz);
    const legH = 7.5;
    for (const [ox, oz] of [[-1.3, -1.3], [1.3, -1.3], [-1.3, 1.3], [1.3, 1.3]]) {
      const leg = box(0.32, legH + 1.4, 0.32, M.timberDark, tx + ox * 1.15, ty + legH / 2, tz + oz * 1.15, { cast: true });
      leg.rotation.z = -ox * 0.045; leg.rotation.x = oz * 0.045;
    }
    // cross braces
    for (const s of [1, -1]) {
      const b1 = box(0.18, 4.4, 0.18, M.timber, tx, ty + 3.4, tz + s * 1.28, { cast: true });
      b1.rotation.x = s * 0.62;
      const b2 = box(0.18, 0.18, 4.4, M.timber, tx + s * 1.28, ty + 3.4, tz, { cast: true });
      b2.rotation.z = -s * 0.62;
    }
    // platform + railing + cap
    box(3.4, 0.3, 3.4, std(rep(T.timber, 2, 2)), tx, ty + legH, tz, { cast: true });
    for (const [ox, oz, w, d] of [[0, -1.6, 3.4, 0.14], [0, 1.6, 3.4, 0.14], [-1.6, 0, 0.14, 3.4], [1.6, 0, 0.14, 3.4]])
      box(w, 0.14, d, M.timberDark, tx + ox, ty + legH + 1.05, tz + oz, { cast: true });
    for (const [ox, oz] of [[-1.6, -1.6], [1.6, -1.6], [-1.6, 1.6], [1.6, 1.6]])
      box(0.14, 1.1, 0.14, M.timberDark, tx + ox, ty + legH + 0.65, tz + oz);
    const cap = new THREE.Mesh(new THREE.ConeGeometry(2.7, 1.7, 4), M.thatch);
    cap.position.set(tx, ty + legH + 2.4, tz); cap.rotation.y = Math.PI / 4;
    cap.castShadow = true; scene.add(cap);
    // ladder (visual)
    for (const s of [-0.35, 0.35]) box(0.12, legH, 0.12, M.timber, tx + s, ty + legH / 2, tz - 1.85, { rx: 0.12 });
    for (let i = 0; i < 9; i++) box(0.8, 0.09, 0.09, M.timber, tx, ty + 0.8 + i * 0.75, tz - 1.85 - i * 0.09);
    solidAt(tx, tz, 3.2, 3.2, legH + 3, ty - 3);
  }

  /* ---------------- earthen ramp + wall-top walkway (south arc) ---------------- */
  {
    const ry0 = terrainHeight(-9, RAMP.z1);
    // packed-earth steps
    const stepMat = std(rep(T.mud, 3, 1));
    for (let i = 0; i < 6; i++) {
      const z = RAMP.z1 + 0.25 + i * 0.44;
      const y = ry0 + 0.25 + i * 0.5;
      box(6, 0.5, 0.5, stepMat, -9, y, z, { cast: true });
    }
    // timber side rails on the ramp
    const railLen = Math.hypot(3, RAMP.z2 - RAMP.z1);
    for (const sx of [-11.9, -6.1]) {
      const rail = box(0.22, 0.22, railLen, M.timberDark, sx, ry0 + 2.1, (RAMP.z1 + RAMP.z2) / 2, { cast: true });
      rail.rotation.x = -Math.atan2(3, RAMP.z2 - RAMP.z1);
      for (const f of [0.15, 0.55, 0.9]) {
        const pz = RAMP.z1 + (RAMP.z2 - RAMP.z1) * f;
        box(0.18, 1.1, 0.18, M.timberDark, sx, terrainHeight(sx, pz) + 0.9 + f * 1.6, pz);
      }
    }
    // walkway deck following the arc, x in [-16,-6.8] and [6.8,16]
    const deckMat = std(rep(T.timber, 4, 1));
    const railMat = M.timberDark;
    for (const [xa, xb] of [[-16, -6.8], [6.8, 16]]) {
      const chunks = 5;
      for (let i = 0; i < chunks; i++) {
        const x0 = xa + (xb - xa) * (i / chunks), x1 = xa + (xb - xa) * ((i + 1) / chunks);
        const cx = (x0 + x1) / 2;
        // ellipse z on the south arc for this x
        const cz = WALL_RZ * Math.sqrt(Math.max(0.05, 1 - (cx / WALL_RX) * (cx / WALL_RX)));
        const segLen = Math.abs(x1 - x0);
        const wy = terrainHeight(cx, 41) + WALL_H + 0.08;
        box(segLen + 0.15, 0.16, 3.6, deckMat, cx, wy, cz, { cast: true });
        // outer railing (posts + rail)
        const oz = cz + 1.75;
        for (const px of [x0 + 0.3, (x0 + x1) / 2, x1 - 0.3])
          box(0.14, 1.1, 0.14, railMat, px, wy + 0.55, oz);
        box(segLen + 0.1, 0.12, 0.12, railMat, cx, wy + 1.05, oz);
        // railing collider (blocks falling off the outer edge)
        solid(x0, oz - 0.1, x1, oz + 0.1, 1.2, wy);
        // low inner parapet — omitted where the earthen ramp joins the walkway
        const iz = cz - 1.75;
        if (!(xa < 0 && cx > -13)) {
          box(segLen + 0.1, 0.55, 0.25, std(rep(T.stone, 2, 0.4)), cx, wy + 0.27, iz, { cast: true });
          solid(x0, iz - 0.15, x1, iz + 0.15, 0.6, wy);
        }
      }
    }
  }

  /* ---------------- fire builders (used by the village below) ---------------- */
  function makeFire(x, y, z, opts = {}) {
    const scale = opts.scale || 1;
    // stone ring
    const ringN = 8;
    for (let i = 0; i < ringN; i++) {
      const a = (i / ringN) * Math.PI * 2 + rng() * 0.3;
      const rr = 0.55 * scale;
      box(0.22 * scale, 0.2 * scale, 0.22 * scale, M.stone,
        x + Math.cos(a) * rr, y + 0.1 * scale, z + Math.sin(a) * rr, { ry: rng() * 3 });
    }
    // charred bed
    const bed = new THREE.Mesh(new THREE.CircleGeometry(0.55 * scale, 12), M.char);
    bed.rotation.x = -Math.PI / 2; bed.position.set(x, y + 0.06, z);
    bed.receiveShadow = true; scene.add(bed);
    // logs
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI + rng() * 0.5;
      const lg = box(0.7 * scale, 0.12 * scale, 0.12 * scale, M.timberDark,
        x + Math.cos(a) * 0.15, y + 0.16 * scale, z + Math.sin(a) * 0.15, { ry: -a });
      lg.rotation.z = 0.12;
    }
    // flame sprite (3-frame strip)
    const ftex = T.flame.clone(); ftex.needsUpdate = true;
    ftex.repeat.set(1 / 3, 1);
    const smat = new THREE.SpriteMaterial({ map: ftex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    const spr = new THREE.Sprite(smat);
    spr.position.set(x, y + 0.75 * scale, z);
    spr.scale.set(1.1 * scale, 1.5 * scale, 1);
    scene.add(spr);
    flameSprites.push({ sprite: spr, tex: ftex, phase: rng() * 3, scale });
    // light (budget: <=8 total)
    if (opts.light !== false) {
      const pl = new THREE.PointLight(0xff8a3a, 9, 15, 2);
      pl.position.set(x, y + 1.2 * scale, z);
      scene.add(pl);
      fireLights.push({ light: pl, base: 9, seed: rng() * 100, x, y, z });
    }
    // smoke emitter
    for (let i = 0; i < 4; i++) {
      const stex = T.smoke;
      const sm = new THREE.SpriteMaterial({ map: stex, transparent: true, depthWrite: false, opacity: 0.3 });
      const sp = new THREE.Sprite(sm);
      sp.position.set(x, y + 1, z);
      scene.add(sp);
      smokePuffs.push({ sprite: sp, life: rng(), x, y: y + 1.2, z, seed: rng() * 10 });
    }
    fires.push({ x, y, z });
    return { x, y, z };
  }
  function makeBrazier(x, y, z, withLight) {
    // iron pole + bowl
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 1.1, 8), M.ironDark);
    pole.position.set(x, y + 0.55, z); pole.castShadow = true; scene.add(pole);
    solidAt(x, z, 0.45, 0.45, 4.5, y - 3);
    const bowl = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.25, 0.3, 10), M.ironDark);
    bowl.position.set(x, y + 1.2, z); bowl.castShadow = true; scene.add(bowl);
    const ftex = T.flame.clone(); ftex.needsUpdate = true;
    ftex.repeat.set(1 / 3, 1);
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: ftex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }));
    spr.position.set(x, y + 1.75, z); spr.scale.set(0.8, 1.1, 1);
    scene.add(spr);
    flameSprites.push({ sprite: spr, tex: ftex, phase: rng() * 3, scale: 0.7 });
    if (withLight) {
      const pl = new THREE.PointLight(0xff8a3a, 8, 13, 2);
      pl.position.set(x, y + 2, z); scene.add(pl);
      fireLights.push({ light: pl, base: 8, seed: rng() * 100, x, y, z });
    }
    for (let i = 0; i < 3; i++) {
      const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: T.smoke, transparent: true, depthWrite: false, opacity: 0.25 }));
      sp.position.set(x, y + 1.5, z); scene.add(sp);
      smokePuffs.push({ sprite: sp, life: rng(), x, y: y + 1.6, z, seed: rng() * 10 });
    }
    fires.push({ x, y, z });
  }

  /* ---------------- village roundhouses ---------------- */
  phase('thatching roofs…');
  const RH = [
    { x: -14, z: 22, enter: 'fire' },     // enterable, fire pit
    { x: 13, z: 18, enter: 'lived' },     // enterable, benches + pots
    { x: -17, z: 8 }, { x: 16, z: 4 }, { x: -13, z: -2 }, { x: 15, z: -8 }, { x: -16, z: -12 },
  ];
  function makePot(x, y, z, s = 1) {
    const pts = [];
    const prof = [[0.02, 0], [0.16, 0.02], [0.26, 0.18], [0.30, 0.38], [0.22, 0.55], [0.14, 0.62], [0.16, 0.72]];
    for (const [r, yy] of prof) pts.push(new THREE.Vector2(r * s, yy * s));
    const pot = new THREE.Mesh(new THREE.LatheGeometry(pts, 12), M.clay);
    pot.position.set(x, y, z); pot.castShadow = true; scene.add(pot);
    return pot;
  }
  function makeBench(x, y, z, len, ry = 0) {
    box(len, 0.12, 0.5, M.timber, x, y + 0.45, z, { ry, cast: true });
    for (const s of [-1, 1]) box(0.4, 0.45, 0.4, M.timberDark, x + s * (len / 2 - 0.4) * Math.cos(ry), y + 0.22, z - s * (len / 2 - 0.4) * Math.sin(ry));
    solidAt(x, z, len, 0.6, 0.6, y);
  }
  for (const rh of RH) {
    const r = 3.1, gy = terrainHeight(rh.x, rh.z);
    const g = new THREE.Group();
    // door faces the street (toward x=0)
    const doorAng = Math.atan2(0 - rh.x, 0 - rh.z); // cylinder-theta convention below
    const gap = rh.enter ? 0.62 : 0; // radians of opening
    // NOTE: CylinderGeometry theta: x = r*sin(t), z = r*cos(t)
    const wall = new THREE.Mesh(
      new THREE.CylinderGeometry(r, r * 1.03, 2.6, 14, 1, true, doorAng + gap / 2, Math.PI * 2 - gap),
      std(rep(T.daub, 4, 1.2), { side: THREE.DoubleSide })
    );
    wall.position.y = 1.3; wall.castShadow = true; wall.receiveShadow = true;
    g.add(wall);
    const roof = new THREE.Mesh(new THREE.ConeGeometry(r + 1.15, 2.5, 14), std(rep(T.thatch, 5, 2)));
    roof.position.y = 2.6 + 1.25; roof.castShadow = true; roof.receiveShadow = true;
    g.add(roof);
    // roof finial
    const fin = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.12, 0.9, 6), M.timberDark);
    fin.position.y = 2.6 + 2.5 + 0.2; g.add(fin);
    if (rh.enter) {
      // door posts + lintel
      const dx = Math.sin(doorAng), dz = Math.cos(doorAng);
      for (const s of [-1, 1]) {
        const px = Math.sin(doorAng + s * gap / 2) * r, pz = Math.cos(doorAng + s * gap / 2) * r;
        const post = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.13, 2.3, 7), M.timberDark);
        post.position.set(px, 1.15, pz); post.castShadow = true; g.add(post);
      }
      const lin = new THREE.Mesh(new THREE.BoxGeometry(gap * r + 0.5, 0.18, 0.18), M.timberDark);
      lin.position.set(dx * (r + 0.05), 2.25, dz * (r + 0.05));
      lin.rotation.y = doorAng; g.add(lin);
      // hide hanging
      const hide = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 1.7),
        new THREE.MeshStandardMaterial({ color: 0x6a4a30, roughness: 0.95, side: THREE.DoubleSide }));
      hide.position.set(dx * (r - 0.15), 1.35, dz * (r - 0.15));
      hide.rotation.y = doorAng + 0.15; g.add(hide);
    }
    // floor
    const floor = new THREE.Mesh(new THREE.CircleGeometry(r - 0.1, 16), M.mudDark);
    floor.rotation.x = -Math.PI / 2; floor.position.y = 0.04; floor.receiveShadow = true; g.add(floor);
    sit(g, rh.x, rh.z);
    // colliders: ring of boxes, skipping the door sector
    const segs = 10;
    for (let i = 0; i < segs; i++) {
      const a = (i / segs) * Math.PI * 2;
      let dA = Math.abs(a - (doorAng % (Math.PI * 2)));
      if (dA > Math.PI) dA = Math.PI * 2 - dA;
      if (rh.enter && dA < 0.5) continue;
      const bx = rh.x + Math.sin(a) * r, bz = rh.z + Math.cos(a) * r;
      solidAt(bx, bz, 1.9, 1.9, 5.6, gy - 3);
    }
    // interiors
    if (rh.enter === 'fire') {
      makeFire(rh.x, gy + 0.04, rh.z, { scale: 0.85 });
      makeBench(rh.x - 1.6, gy, rh.z + 1.2, 2.2, 0.5);
      makeBench(rh.x + 1.7, gy, rh.z - 1.0, 2.2, -0.4);
      makePot(rh.x + 1.2, gy + 0.04, rh.z + 1.6, 0.9);
    } else if (rh.enter === 'lived') {
      makeBench(rh.x - 1.4, gy, rh.z, 2.6, Math.PI / 2);
      makeBench(rh.x + 1.4, gy, rh.z + 0.4, 2.2, Math.PI / 2);
      makePot(rh.x + 0.4, gy + 0.04, rh.z - 1.4, 1.1);
      makePot(rh.x - 0.7, gy + 0.04, rh.z - 1.2, 0.8);
      // stored crate + barrel
      const crate = await loadGlb('assets/props/crate.glb');
      sit(crate.scene, rh.x + 1.9, rh.z + 1.5);
      crate.scene.rotation.y = 0.5;
      crate.scene.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    }
  }

  /* ---------------- feasting hall (18, -5) ---------------- */
  {
    const hx = 18, hz = -5, gy = terrainHeight(hx, hz);
    const W = 15, D = 7, WH = 2.9, RHgt = 3.1;
    const wallMat = std(rep(T.timber, 6, 1.4));
    // long walls
    for (const s of [-1, 1]) {
      box(W, WH, 0.32, wallMat, hx, gy + WH / 2, hz + s * D / 2, { cast: true });
      solid(hx - W / 2, hz + s * D / 2 - 0.16, hx + W / 2, hz + s * D / 2 + 0.16, WH + 3, gy - 3);
    }
    // gable ends (triangles) — west end has the door
    const triShape = new THREE.Shape();
    triShape.moveTo(-D / 2, 0); triShape.lineTo(D / 2, 0); triShape.lineTo(0, RHgt); triShape.closePath();
    const triGeo = new THREE.ShapeGeometry(triShape);
    const gableMat = std(rep(T.timber, 3, 1.5), { side: THREE.DoubleSide });
    for (const [ex, flip] of [[hx - W / 2, 0], [hx + W / 2, 1]]) {
      const gm = new THREE.Mesh(triGeo, gableMat);
      gm.position.set(ex, gy + WH, hz);
      gm.rotation.y = flip ? -Math.PI / 2 : Math.PI / 2;
      gm.castShadow = true; scene.add(gm);
    }
    // gable end walls below the triangles; west end (street side) has the door
    const exw = hx - W / 2, exe = hx + W / 2;
    // east end: solid
    box(0.32, WH, D, wallMat, exe, gy + WH / 2, hz, { cast: true });
    solid(exe - 0.16, hz - D / 2, exe + 0.16, hz + D / 2, WH + 3, gy - 3);
    // west end: two leaves with a 2.2m door gap
    for (const s of [-1, 1]) {
      const segW = D / 2 - 1.1;
      box(0.32, WH, segW, wallMat, exw, gy + WH / 2, hz + s * (1.1 + segW / 2), { cast: true });
    }
    solid(exw - 0.16, hz - D / 2, exw + 0.16, hz - 1.1, WH + 3, gy - 3);
    solid(exw - 0.16, hz + 1.1, exw + 0.16, hz + D / 2, WH + 3, gy - 3);
    // door posts + lintel
    for (const s of [-1, 1]) {
      const post = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.15, 2.5, 7), M.timberDark);
      post.position.set(exw, gy + 1.25, hz + s * 1.1); post.castShadow = true; scene.add(post);
    }
    box(0.2, 0.22, 2.7, M.timberDark, exw, gy + 2.55, hz, { cast: true });
    // roof: two sloped planes
    const slopeLen = Math.hypot(D / 2 + 1.1, RHgt) + 0.5;
    const roofMat = std(rep(T.thatch, 7, 3));
    for (const s of [-1, 1]) {
      const rp = box(W + 1.8, 0.18, slopeLen, roofMat, hx, gy + WH + RHgt / 2 - 0.1, hz + s * (D / 4 + 0.28), { cast: true });
      rp.rotation.x = s * Math.atan2(RHgt, D / 2 + 1.1);
    }
    // ridge beam
    box(W + 2, 0.28, 0.28, M.timberDark, hx, gy + WH + RHgt, hz, { cast: true });
    // interior posts
    for (const px of [hx - 4.5, hx, hx + 4.5]) for (const s of [-1, 1]) {
      box(0.3, WH, 0.3, M.timberDark, px, gy + WH / 2, hz + s * 2.2, { cast: true });
      solidAt(px, hz + s * 2.2, 0.4, 0.4, WH + 3, gy - 3);
    }
    // central hearth
    makeFire(hx, gy + 0.05, hz, { scale: 1.25 });
    // long benches
    for (const s of [-1, 1]) {
      box(9, 0.14, 0.55, M.timber, hx, gy + 0.5, hz + s * 1.7, { cast: true });
      for (const e of [-3.6, 3.6]) box(0.45, 0.5, 0.45, M.timberDark, hx + e, gy + 0.25, hz + s * 1.7);
      solidAt(hx, hz + s * 1.7, 9, 0.7, 3.6, gy - 3);
    }
    // floor
    const fl = new THREE.Mesh(new THREE.PlaneGeometry(W - 0.4, D - 0.4), M.mudDark);
    fl.rotation.x = -Math.PI / 2; fl.position.set(hx, gy + 0.05, hz);
    fl.receiveShadow = true; scene.add(fl);
  }

  /* ---------------- forge (-16, 8) ---------------- */
  let forgePos = null;
  {
    const fx = -16, fz = 8, gy = terrainHeight(fx, fz);
    forgePos = new THREE.Vector3(fx, gy, fz);
    // open shelter: 4 posts + sloped roof
    for (const [ox, oz] of [[-3, -2], [3, -2], [-3, 2], [3, 2]]) {
      box(0.3, 3.3, 0.3, M.timberDark, fx + ox, gy + 1.65, fz + oz, { cast: true });
      solidAt(fx + ox, fz + oz, 0.4, 0.4, 6.3, gy - 3);
    }
    const roof = box(7.6, 0.16, 5.4, std(rep(T.thatch, 4, 3)), fx, gy + 3.8, fz, { cast: true });
    roof.rotation.z = 0.12;
    // anvil: base + waist + top + horn
    const ax = fx - 1.2, az = fz + 0.4;
    box(0.55, 0.5, 0.55, M.ironDark, ax, gy + 0.25, az, { cast: true });
    box(1.15, 0.32, 0.42, M.ironDark, ax, gy + 0.68, az, { cast: true });
    const horn = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.2, 0.7, 8), M.ironDark);
    horn.rotation.z = Math.PI / 2 - 0.25; horn.position.set(ax + 0.85, gy + 0.72, az);
    horn.castShadow = true; scene.add(horn);
    solidAt(ax, az, 1.4, 0.6, 3.9, gy - 3);
    // quench barrel (asset)
    const barrel = await loadGlb('assets/props/barrel.glb');
    sit(barrel.scene, fx + 1.6, fz - 1.2);
    barrel.scene.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    solidAt(fx + 1.6, fz - 1.2, 0.9, 0.9, 4.2, gy - 3);
    // forge fire
    makeFire(fx + 0.6, gy + 0.02, fz + 1.0, { scale: 1.0 });
    // weapon rack with Quaternius arms
    const rx = fx - 2.6, rz = fz - 1.6;
    for (const s of [-1, 1]) box(0.16, 1.6, 0.16, M.timberDark, rx + s * 1.1, gy + 0.8, rz, { cast: true });
    box(2.5, 0.12, 0.12, M.timberDark, rx, gy + 1.5, rz, { cast: true });
    solidAt(rx, rz, 2.5, 0.5, 4.6, gy - 3);
    const spear = await loadGlb('assets/weapons/Spear.glb');
    spear.scene.position.set(rx - 0.7, gy, rz + 0.1); spear.scene.rotation.z = 0.28;
    spear.scene.traverse(o => { if (o.isMesh) o.castShadow = true; });
    scene.add(spear.scene);
    const sword = await loadGlb('assets/weapons/Sword.glb');
    sword.scene.position.set(rx + 0.1, gy + 0.05, rz + 0.15); sword.scene.rotation.z = 1.35; sword.scene.rotation.y = 0.4;
    sword.scene.traverse(o => { if (o.isMesh) o.castShadow = true; });
    scene.add(sword.scene);
    const shR = await loadGlb('assets/weapons/Shield_Round.glb');
    shR.scene.position.set(rx + 0.9, gy + 0.55, rz + 0.25); shR.scene.rotation.x = -0.25; shR.scene.rotation.y = 0.5;
    shR.scene.traverse(o => { if (o.isMesh) o.castShadow = true; });
    scene.add(shR.scene);
    const shC = await loadGlb('assets/weapons/Shield_Celtic_Golden.glb');
    shC.scene.position.set(rx + 2.1, gy + 0.55, rz - 0.9); shC.scene.rotation.y = -0.9; shC.scene.rotation.x = -0.2;
    shC.scene.traverse(o => { if (o.isMesh) o.castShadow = true; });
    scene.add(shC.scene);
    // workbench
    box(2.2, 0.14, 0.85, M.timber, fx + 1.8, gy + 0.9, fz + 1.4, { cast: true });
    for (const [ox, oz] of [[-0.9, -0.3], [0.9, -0.3], [-0.9, 0.3], [0.9, 0.3]])
      box(0.14, 0.9, 0.14, M.timberDark, fx + 1.8 + ox, gy + 0.45, fz + 1.4 + oz);
    solidAt(fx + 1.8, fz + 1.4, 2.3, 1.0, 4, gy - 3);
    // log pile (asset)
    const logs = await loadGlb('assets/props/log_stack.glb');
    sit(logs.scene, fx - 2.8, fz + 1.8);
    logs.scene.rotation.y = 0.7;
    logs.scene.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    solidAt(fx - 2.8, fz + 1.8, 1.6, 1.0, 4, gy - 3);
  }

  /* ---------------- druid grove (-28, -25) ---------------- */
  phase('waking the old oaks…');
  {
    const gx = -28, gz = -25;
    const oakGlb = await loadGlb('assets/trees/tree_oak.glb');
    const oakDarkGlb = await loadGlb('assets/trees/tree_oak_dark.glb');
    const mossGlb = await loadGlb('assets/trees/hanging_moss.glb');
    const spots = [[-6, -4], [5, -6], [7, 4], [-5, 6], [0, -9], [-9, 1], [2, 9]];
    let k = 0;
    for (const [ox, oz] of spots) {
      const src = k % 2 ? oakDarkGlb : oakGlb;
      const tree = src.scene.clone();
      const s = 2.2 + rng() * 0.9; // old, big oaks
      tree.scale.setScalar(s);
      sit(tree, gx + ox, gz + oz);
      tree.rotation.y = rng() * Math.PI * 2;
      tree.traverse(o => {
        if (o.isMesh) {
          o.castShadow = true; o.receiveShadow = true;
          if (o.material && o.material.color && !o.material.userData.duskDimmed) {
            o.material = o.material.clone();
            o.material.color.multiplyScalar(0.85);
            o.material.userData.duskDimmed = true;
          }
        }
      });
      solidAt(gx + ox, gz + oz, 1.1, 1.1, 6.2, terrainHeight(gx + ox, gz + oz) - 3);
      // hanging moss draped in the canopy — small, tucked inside the crown
      for (let mI = 0; mI < 3; mI++) {
        const moss = mossGlb.scene.clone();
        moss.scale.setScalar(s * 0.7);
        const mx = gx + ox + (rng() - 0.5) * 2.4, mz = gz + oz + (rng() - 0.5) * 2.4;
        moss.position.set(mx, terrainHeight(mx, mz) + s * 0.62 + rng() * 0.3, mz);
        moss.rotation.y = rng() * 6;
        moss.traverse(o => {
          if (o.isMesh && o.material && o.material.color) {
            o.material = o.material.clone();
            o.material.color.multiply(new THREE.Color(0.32, 0.48, 0.33)); // kill the cyan: dark moss green
            o.material.side = THREE.DoubleSide;
          }
        });
        scene.add(moss);
      }
      k++;
    }
    // stone circle: 8 standing stones + altar slab
    const stoneMat = new THREE.MeshStandardMaterial({ color: 0x8a8478, roughness: 0.95 });
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      const sx = gx + Math.cos(a) * 4.2, sz = gz + Math.sin(a) * 4.2;
      const sy = terrainHeight(sx, sz);
      const st = box(0.85, 1.5 + rng() * 0.5, 0.55, stoneMat, sx, sy + 0.7, sz,
        { ry: a + (rng() - 0.5) * 0.5, cast: true });
      st.rotation.z = (rng() - 0.5) * 0.14;
      solidAt(sx, sz, 1.0, 1.0, 4.8, sy - 3);
    }
    const ay = terrainHeight(gx, gz);
    box(1.7, 0.55, 1.2, stoneMat, gx, ay + 0.27, gz, { ry: 0.4, cast: true });
    solidAt(gx, gz, 1.7, 1.2, 3.6, ay - 3);
  }

  /* ---------------- livestock pens (28, -20) ---------------- */
  phase('penning the livestock…');
  const mixers = [];
  {
    const pen = { x1: 22, z1: -28, x2: 38, z2: -12 };
    const pgy = terrainHeight(30, -20);
    // procedural post-and-rail runs (the asset cross pieces mark corners + gate)
    function fenceRun(x0, z0, x1, z1, skip) {
      const len = Math.hypot(x1 - x0, z1 - z0);
      const n = Math.max(1, Math.round(len / 2.2));
      for (let i = 0; i <= n; i++) {
        const f = i / n;
        const x = x0 + (x1 - x0) * f, z = z0 + (z1 - z0) * f;
        if (skip && skip(x, z)) continue;
        const py = terrainHeight(x, z);
        box(0.16, 1.35, 0.16, M.timberDark, x, py + 0.67, z, { cast: true });
        if (i < n) {
          const f2 = (i + 1) / n;
          const nx2 = x0 + (x1 - x0) * f2, nz2 = z0 + (z1 - z0) * f2;
          if (skip && skip(nx2, nz2)) continue;
          const mx = (x + nx2) / 2, mz = (z + nz2) / 2;
          const my = terrainHeight(mx, mz);
          const segLen = Math.hypot(nx2 - x, nz2 - z);
          const yaw = Math.atan2(nx2 - x, nz2 - z);
          for (const ry of [0.55, 1.0]) {
            const rail = box(0.09, 0.12, segLen + 0.1, M.timber, mx, my + ry, mz, { cast: true });
            rail.rotation.y = yaw;
          }
        }
      }
    }
    // gate gap on the west side, facing the village
    const gap = (x, z) => Math.abs(x - pen.x1) < 1.2 && z > -22 && z < -18;
    fenceRun(pen.x1, pen.z1, pen.x2, pen.z1);
    fenceRun(pen.x2, pen.z1, pen.x2, pen.z2);
    fenceRun(pen.x2, pen.z2, pen.x1, pen.z2);
    fenceRun(pen.x1, pen.z2, pen.x1, pen.z1, gap);
    // asset fence crosses: corners + gate posts
    const fenceGlb = await loadGlb('assets/props/structure-fence.glb');
    for (const [fx2, fz2] of [[pen.x1, pen.z1], [pen.x2, pen.z1], [pen.x2, pen.z2], [pen.x1, pen.z2], [pen.x1, -22], [pen.x1, -18]]) {
      const fg = fenceGlb.scene.clone();
      fg.scale.set(0.85, 0.62, 0.85);
      fg.position.set(fx2, terrainHeight(fx2, fz2), fz2);
      fg.rotation.y = rng() * Math.PI;
      fg.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
      scene.add(fg);
    }
    // colliders (leave the gate gap open)
    solid(pen.x1 - 0.2, pen.z1 - 0.2, pen.x2 + 0.2, pen.z1 + 0.2, 2.2, pgy - 0.5);
    solid(pen.x2 - 0.2, pen.z1 - 0.2, pen.x2 + 0.2, pen.z2 + 0.2, 2.2, pgy - 0.5);
    solid(pen.x1 - 0.2, pen.z2 - 0.2, pen.x2 + 0.2, pen.z2 + 0.2, 2.2, pgy - 0.5);
    solid(pen.x1 - 0.2, pen.z1 - 0.2, pen.x1 + 0.2, -22, 2.2, pgy - 0.5);
    solid(pen.x1 - 0.2, -18, pen.x1 + 0.2, pen.z2 + 0.2, 2.2, pgy - 0.5);
    // mud decal
    const mud = new THREE.Mesh(new THREE.CircleGeometry(8.5, 20),
      new THREE.MeshStandardMaterial({ map: rep(T.mudDark, 5, 5), roughness: 1, transparent: true, opacity: 0.9, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 }));
    mud.rotation.x = -Math.PI / 2;
    mud.position.set(30, terrainHeight(30, -20) + 0.05, -20);
    mud.receiveShadow = true; scene.add(mud);
    // animals with idle clips
    const herd = [
      ['assets/animals/Sheep.glb', 26, -16, 1.0], ['assets/animals/Sheep.glb', 31, -22, 1.0],
      ['assets/animals/Sheep.glb', 34, -17, 1.0],
      ['assets/animals/Cow.glb', 27, -25, 1.0], ['assets/animals/Cow.glb', 34.5, -24, 1.0],
      ['assets/animals/Pig.glb', 30, -19, 1.0],
    ];
    for (const [path, ax, az, s] of herd) {
      const glb = await loadGlb(path);
      const a = glb.scene;
      a.scale.setScalar(s);
      sit(a, ax, az);
      a.rotation.y = rng() * Math.PI * 2;
      a.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
      const idle = glb.animations.find(c => /idle/i.test(c.name));
      if (idle) {
        const mx = new THREE.AnimationMixer(a);
        mx.clipAction(idle).play();
        mixers.push(mx);
      }
    }
    // hay: firewood pile as fodder stack
    const fod = await loadGlb('assets/props/firewood_pile.glb');
    sit(fod.scene, 24.5, -25.5);
    fod.scene.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  }

  /* ---------------- cookfires ---------------- */
  phase('kindling hearth fires…');
  makeFire(12, terrainHeight(12, 12), 12, { scale: 1.0 });
  makeFire(-9.5, terrainHeight(-9.5, -3.5), -3.5, { scale: 1.0 });
  makeFire(10, terrainHeight(10, -14), -14, { scale: 1.0 });
  // traveler's campfire outside the gate — smoke for the arrival view (no light: budget is full)
  makeFire(-7, terrainHeight(-7, 58), 58, { scale: 0.9, light: false });

  /* ---------------- fields (outside S/E) ---------------- */
  phase('sowing the fields…');
  const FIELD_RECTS = [
    { x1: -38, z1: 58, x2: -14, z2: 92 },
    { x1: 16, z1: 58, x2: 46, z2: 94 },
  ];
  const cropSpots = [];
  for (const fr of FIELD_RECTS) {
    const nx = 26, nz = 14;
    const verts = [], uvs = [], idx = [];
    for (let j = 0; j <= nz; j++) {
      for (let i = 0; i <= nx; i++) {
        const x = fr.x1 + (fr.x2 - fr.x1) * (i / nx);
        const z = fr.z1 + (fr.z2 - fr.z1) * (j / nz);
        const ridge = 0.16 * Math.abs(Math.sin((x - fr.x1) * 2.1)) + 0.05;
        verts.push(x, terrainHeight(x, z) + ridge, z);
        uvs.push((x - fr.x1) / 5, (z - fr.z1) / 5);
        if (i < nx && j < nz) {
          const b = j * (nx + 1) + i;
          idx.push(b, b + nx + 1, b + 1, b + 1, b + nx + 1, b + nx + 2);
        }
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uvs, 2));
    g.setIndex(idx);
    g.computeVertexNormals();
    const fm = new THREE.Mesh(g, new THREE.MeshStandardMaterial({ map: rep(T.crops, 1, 1), roughness: 0.95 }));
    fm.receiveShadow = true;
    scene.add(fm);
    // crop tuft spots on the ridges
    const n = 320;
    for (let i = 0; i < n; i++) {
      const x = fr.x1 + rng() * (fr.x2 - fr.x1);
      const z = fr.z1 + rng() * (fr.z2 - fr.z1);
      // snap to ridge tops: ridges run along z, peaks where sin = ±1
      const ridgeX = fr.x1 + (Math.round((x - fr.x1) * 2.1 / Math.PI - 0.5) * Math.PI + Math.PI / 2) / 2.1;
      const px = THREE.MathUtils.clamp(ridgeX, fr.x1 + 0.3, fr.x2 - 0.3);
      cropSpots.push([px + (rng() - 0.5) * 0.3, terrainHeight(px, z) + 0.2, z]);
    }
  }
  {
    const tuftGlb = await loadGlb('assets/nature/grass_large.glb');
    const parts = [];
    tuftGlb.scene.traverse(o => { if (o.isMesh) parts.push({ geo: o.geometry, mat: o.material.clone() }); });
    parts.forEach(p => { p.mat.color = new THREE.Color(0xcfa64e); }); // ripe gold
    for (const p of parts) {
      const inst = new THREE.InstancedMesh(p.geo, p.mat, cropSpots.length);
      const d = new THREE.Object3D();
      cropSpots.forEach((s, i) => {
        d.position.set(s[0], s[1], s[2]);
        d.rotation.y = rng() * Math.PI * 2;
        d.scale.setScalar(0.9 + rng() * 0.9);
        d.updateMatrix();
        inst.setMatrixAt(i, d.matrix);
      });
      inst.instanceMatrix.needsUpdate = true;
      inst.receiveShadow = true;
      inst.frustumCulled = false;
      scene.add(inst);
    }
  }

  /* ---------------- forest ring (r > 70, denser N/W) ---------------- */
  phase('growing the wildwood…');
  {
    const types = [
      { path: 'assets/trees/tree_pineTallA_detailed.glb', w: 3, s: [1.7, 2.9] },
      { path: 'assets/trees/tree_pineTallB_detailed.glb', w: 3, s: [1.7, 2.9] },
      { path: 'assets/trees/tree_pineDefaultA.glb', w: 2, s: [1.6, 2.6] },
      { path: 'assets/trees/tree_pineRoundA.glb', w: 1.5, s: [1.6, 2.6] },
      { path: 'assets/trees/tree_oak.glb', w: 1.5, s: [1.5, 2.3] },
      { path: 'assets/trees/tree_oak_dark.glb', w: 1.5, s: [1.5, 2.3] },
    ];
    const bag = [];
    const totalW = types.reduce((a, t) => a + t.w, 0);
    const dummy = new THREE.Object3D();
    let placed = 0, guard = 0;
    const spots = [];
    while (placed < 120 && guard++ < 4000) {
      const a = rng() * Math.PI * 2;
      const r = 72 + 58 * Math.sqrt(rng());
      const x = Math.cos(a) * r, z = Math.sin(a) * r;
      let p = 0.35;
      if (z < 0) p += 0.35;   // denser north
      if (x < 0) p += 0.25;   // denser west
      if (rng() > p) continue;
      if (Math.abs(x) < 9 && z > 35) continue;               // road corridor
      if (FIELD_RECTS.some(fr => x > fr.x1 - 3 && x < fr.x2 + 3 && z > fr.z1 - 3 && z < fr.z2 + 3)) continue;
      if (Math.hypot(x - 6, z - 70) < 11) continue;          // trader cart clearing
      spots.push([x, z]);
      placed++;
    }
    // assign types
    for (const [x, z] of spots) {
      let pick = rng() * totalW, ti = 0;
      for (; ti < types.length - 1; ti++) { pick -= types[ti].w; if (pick <= 0) break; }
      const t = types[ti];
      const s = t.s[0] + rng() * (t.s[1] - t.s[0]);
      dummy.position.set(x, terrainHeight(x, z) - 0.1, z);
      dummy.rotation.set(0, rng() * Math.PI * 2, 0);
      dummy.scale.setScalar(s);
      dummy.updateMatrix();
      bag.push({ ti, matrix: dummy.matrix.clone() });
      if (Math.hypot(x, z) < 100) solidAt(x, z, 0.9, 0.9, 7, terrainHeight(x, z) - 3);
    }
    // build one InstancedMesh per (type, mesh part)
    for (let ti = 0; ti < types.length; ti++) {
      const glb = await loadGlb(types[ti].path);
      const parts = [];
      glb.scene.traverse(o => { if (o.isMesh) parts.push({ geo: o.geometry, mat: o.material }); });
      // KHR_materials_unlit renders full-bright: pull it down into the dusk
      new Set(parts.map(p => p.mat)).forEach(m => { if (m.color) m.color.multiplyScalar(0.82); });
      const mine = bag.filter(b => b.ti === ti);
      for (const part of parts) {
        const inst = new THREE.InstancedMesh(part.geo, part.mat, Math.max(1, mine.length));
        mine.forEach((b, i) => inst.setMatrixAt(i, b.matrix));
        inst.count = mine.length;
        inst.instanceMatrix.needsUpdate = true;
        inst.castShadow = true; inst.receiveShadow = true;
        inst.frustumCulled = false;
        scene.add(inst);
      }
    }
  }

  /* ---------------- grass tufts + rocks (instanced scatter) ---------------- */
  {
    const grassGlb = await loadGlb('assets/nature/grass.glb');
    const gparts = [];
    grassGlb.scene.traverse(o => { if (o.isMesh) gparts.push({ geo: o.geometry, mat: o.material }); });
    const spots = [];
    let guard = 0;
    while (spots.length < 650 && guard++ < 8000) {
      let x, z;
      if (rng() < 0.7) { const a = rng() * Math.PI * 2, r = 8 + 40 * Math.sqrt(rng()); x = Math.cos(a) * r; z = Math.sin(a) * r; }
      else { x = (rng() - 0.5) * 12; z = 44 + rng() * 66; }
      if (PADS.some(p => Math.hypot(x - p.x, z - p.z) < p.r * 0.8)) continue;
      if (x > 20 && x < 40 && z > -30 && z < -10) continue; // pens
      spots.push([x, terrainHeight(x, z), z]);
    }
    const dummy = new THREE.Object3D();
    // kill the asset's teal cast: push tufts toward dry late-summer olive
    const olive = new THREE.Color(0.72, 0.88, 0.55);
    new Set(gparts.map(p => p.mat)).forEach(m => { if (m.color) { m.color.multiplyScalar(0.9); m.color.multiply(olive); } });
    for (const p of gparts) {
      const inst = new THREE.InstancedMesh(p.geo, p.mat, spots.length);
      spots.forEach((s, i) => {
        dummy.position.set(s[0], s[1], s[2]);
        dummy.rotation.y = rng() * Math.PI * 2;
        dummy.scale.setScalar(0.8 + rng() * 0.8);
        dummy.updateMatrix();
        inst.setMatrixAt(i, dummy.matrix);
      });
      inst.instanceMatrix.needsUpdate = true;
      inst.receiveShadow = true;
      inst.frustumCulled = false;
      scene.add(inst);
    }
    // rocks
    const rockGlbA = await loadGlb('assets/nature/rock_smallA.glb');
    const rockGlbB = await loadGlb('assets/nature/rock_smallB.glb');
    const rparts = [];
    [rockGlbA, rockGlbB].forEach(glb => glb.scene.traverse(o => { if (o.isMesh) rparts.push({ geo: o.geometry, mat: o.material }); }));
    const rspots = [];
    for (let i = 0; i < 40; i++) {
      const a = rng() * Math.PI * 2, r = 50 + 70 * rng();
      const x = Math.cos(a) * r, z = Math.sin(a) * r;
      rspots.push([x, terrainHeight(x, z), z, 0.7 + rng() * 1.1]);
    }
    new Set(rparts.map(p => p.mat)).forEach(m => { if (m.color) m.color.multiplyScalar(0.88); });
    for (const p of rparts) {
      const inst = new THREE.InstancedMesh(p.geo, p.mat, rspots.length);
      rspots.forEach((s, i) => {
        dummy.position.set(s[0], s[1] - 0.1, s[2]);
        dummy.rotation.y = rng() * Math.PI * 2;
        dummy.scale.setScalar(s[3]);
        dummy.updateMatrix();
        inst.setMatrixAt(i, dummy.matrix);
      });
      inst.instanceMatrix.needsUpdate = true;
      inst.castShadow = true; inst.receiveShadow = true;
      inst.frustumCulled = false;
      scene.add(inst);
    }
    // two landmark boulders near the grove
    const bigGlb = await loadGlb('assets/nature/rock_largeA.glb');
    for (const [bx, bz] of [[-38, -18], [-18, -34]]) {
      const b = bigGlb.scene.clone();
      b.scale.setScalar(1.6);
      sit(b, bx, bz);
      b.rotation.y = rng() * 6;
      b.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
      solidAt(bx, bz, 2.2, 2.2, 5.4, terrainHeight(bx, bz) - 3);
    }
  }

  /* ---------------- trader cart (6, 70) ---------------- */
  phase('loading the trader\'s cart…');
  {
    const cx = 6, cz = 70, gy = terrainHeight(cx, cz);
    const cart = new THREE.Group();
    // bed
    const bed = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.35, 3.2), M.timber);
    bed.position.y = 1.05; bed.castShadow = true; cart.add(bed);
    // side rails
    for (const s of [-1, 1]) {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.5, 3.2), M.timberDark);
      rail.position.set(s * 0.85, 1.45, 0); rail.castShadow = true; cart.add(rail);
    }
    // wheels
    const wheelGeo = new THREE.CylinderGeometry(0.55, 0.55, 0.12, 12);
    for (const [ox, oz] of [[-0.95, -1.05], [0.95, -1.05], [-0.95, 1.05], [0.95, 1.05]]) {
      const w = new THREE.Mesh(wheelGeo, M.timberDark);
      w.rotation.z = Math.PI / 2; w.position.set(ox, 0.55, oz);
      w.castShadow = true; cart.add(w);
      // hub
      const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.16, 8), M.ironDark);
      hub.rotation.z = Math.PI / 2; hub.position.set(ox, 0.55, oz); cart.add(hub);
    }
    // shafts
    for (const s of [-1, 1]) {
      const sh = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 2.8), M.timber);
      sh.position.set(s * 0.6, 0.75, 2.6); sh.rotation.x = -0.18; sh.castShadow = true; cart.add(sh);
    }
    // amphorae: lathe-turned, 7 of them, one with a red Roman band
    const prof = [[0.03, 0], [0.17, 0.03], [0.30, 0.25], [0.34, 0.5], [0.26, 0.72], [0.14, 0.82], [0.13, 0.95], [0.17, 1.0]];
    const apts = prof.map(([r, y]) => new THREE.Vector2(r, y));
    const aGeo = new THREE.LatheGeometry(apts, 14);
    const spotsA = [[-0.45, -1.0], [0.4, -1.05], [-0.42, -0.1], [0.44, -0.05], [-0.4, 0.85], [0.42, 0.9], [0, 0.35]];
    spotsA.forEach(([ox, oz], i) => {
      const am = new THREE.Mesh(aGeo, M.clay);
      am.position.set(ox, 1.22, oz); am.castShadow = true; cart.add(am);
      if (i === 3) {
        // red painted band — Roman goods pressing in
        const band = new THREE.Mesh(new THREE.CylinderGeometry(0.345, 0.345, 0.14, 14), M.red);
        band.position.set(ox, 1.22 + 0.5, oz); cart.add(band);
      }
    });
    cart.position.set(cx, gy, cz);
    cart.rotation.y = 0.12;
    scene.add(cart);
    solidAt(cx, cz, 2.4, 3.6, 5, gy - 3);
    // firewood pile beside the cart
    const fw = await loadGlb('assets/props/firewood_pile.glb');
    sit(fw.scene, cx + 2.6, cz + 1.2);
    fw.scene.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
  }

  /* ---------------- fresh grave (-22, -31) ---------------- */
  {
    const gx = -22, gz = -31, gy = terrainHeight(gx, gz);
    const mound = new THREE.Mesh(new THREE.SphereGeometry(1, 14, 10), std(rep(T.mudDark, 2, 1)));
    mound.scale.set(1.3, 0.45, 2.0);
    mound.position.set(gx, gy + 0.05, gz);
    mound.castShadow = true; mound.receiveShadow = true; scene.add(mound);
    // wooden marker
    const mk1 = box(0.14, 1.3, 0.14, M.timberDark, gx, gy + 0.65, gz - 1.7, { cast: true });
    mk1.rotation.x = 0.06;
    box(0.7, 0.12, 0.12, M.timberDark, gx, gy + 1.05, gz - 1.68, { cast: true });
    // offering pot of grain
    makePot(gx + 0.5, gy + 0.35, gz + 0.9, 0.75);
    solidAt(gx, gz - 1.7, 0.4, 0.4, 4.4, gy - 3);
  }

  /* ---------------- background figures (3, static, distant) ---------------- */
  {
    const fig = async (path, x, z, ry, sitY) => {
      const glb = await loadGlb(path);
      const m = glb.scene;
      if (sitY !== undefined) { m.position.set(x, sitY, z); scene.add(m); }
      else sit(m, x, z);
      m.rotation.y = ry;
      m.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
      solidAt(x, z, 0.55, 0.55, 4.6, terrainHeight(x, z) - 3);
    };
    // woman tending the cookfire at (12,12), seated on a log
    const ly = terrainHeight(13.4, 12.4);
    box(1.4, 0.35, 0.35, M.timberDark, 13.4, ly + 0.18, 12.4, { ry: 0.4, cast: true });
    await fig('assets/characters/Female_Sitting.glb', 13.4, 12.15, Math.PI + 0.5, ly + 0.32);
    // man by the hall door
    await fig('assets/characters/Male_Standing.glb', 10.6, -2.6, -Math.PI / 2 + 0.3);
    // woman at the pen gate
    await fig('assets/characters/Female_Standing.glb', 20.6, -20, Math.PI / 2);
  }

  /* ---------------- ground mist ---------------- */
  phase('calling up the mist…');
  const mists = [];
  {
    const defs = [];
    for (let i = 0; i < 12; i++) defs.push([-28 + (rng() - 0.5) * 30, -25 + (rng() - 0.5) * 26]);
    defs.push([-26, 75], [-20, 68], [30, 78], [24, 66], [-30, 84], [36, 70], [-34, 62], [28, 88]);
    for (const [mx, mz] of defs) {
      const sm = new THREE.SpriteMaterial({ map: T.mist, transparent: true, depthWrite: false, opacity: 0.10 + rng() * 0.06 });
      const sp = new THREE.Sprite(sm);
      const w = 13 + rng() * 9;
      sp.scale.set(w, w * 0.38, 1);
      const my = terrainHeight(mx, mz);
      sp.position.set(mx, my + 1.1 + rng() * 0.8, mz);
      scene.add(sp);
      mists.push({ sprite: sp, x0: mx, z0: mz, y: my + 1.1, seed: rng() * 20, range: 6 + rng() * 6, speed: 0.05 + rng() * 0.08 });
    }
  }

  /* ---------------- POI interactables ---------------- */
  const poiPanel = document.getElementById('poiPanel');
  const poiTitle = document.getElementById('poiTitle');
  const poiBody = document.getElementById('poiBody');
  let poiTimer = null, poiOpenId = null;
  function showPOI(id, title, body) {
    if (poiOpenId === id) { // second press dismisses
      poiPanel.classList.add('hidden'); poiOpenId = null; clearTimeout(poiTimer); return;
    }
    poiOpenId = id;
    poiTitle.textContent = title;
    poiBody.textContent = body;
    poiPanel.classList.remove('hidden');
    clearTimeout(poiTimer);
    poiTimer = setTimeout(() => { poiPanel.classList.add('hidden'); poiOpenId = null; }, 11000);
  }
  function addPOI(id, x, y, z, prompt, title, body, size = [2.6, 2.4, 2.6]) {
    const px = new THREE.Mesh(new THREE.BoxGeometry(...size), proxyMat);
    px.position.set(x, y, z);
    scene.add(px);
    interactables.push({
      id, proxy: px,
      getPrompt: () => prompt,
      canUse: () => true,
      use: () => showPOI(id, title, body),
    });
  }
  const gyGate = terrainHeight(0, 40);
  addPOI('gate', 0, gyGate + 1.4, 40,
    'E · inspect the rampart',
    'THE MURUS GALLICUS',
    'A core of earth and rubble faced with dry stone, pinned clean through with oak beams — it will not burn, and no ram has ever hurried it. Caesar\u2019s engineers took notes outside Avaricum, and learned nothing cheap.');
  const gyHall = terrainHeight(18, -5);
  addPOI('hearth', 18, gyHall + 1.2, -5,
    'E · inspect the hearth',
    'THE CHIEF\u2019S HEARTH',
    'This fire never quite goes out. They say a hall is only as warm as its last story — tonight the benches hold smoke, old wars, and somebody\u2019s grandfather\u2019s boar.');
  const gyGrove = terrainHeight(-28, -25);
  addPOI('grove', -28, gyGrove + 1.2, -25,
    'E · inspect the stones',
    'THE DRUID\u2019S CIRCLE',
    'Eight stones, older than the rampart, older than the name of this hill. The druids leave them offerings; the mist does the rest. Best not to count them twice.');
  const gyGrave = terrainHeight(-22, -31);
  addPOI('grave', -22, gyGrave + 0.9, -31,
    'E · inspect the grave',
    'FRESH EARTH',
    'Turned soil, still dark. A wooden marker, a pot of grain for the road. Someone was loved here, and recently.');
  const gyCart = terrainHeight(6, 70);
  addPOI('cart', 6, gyCart + 1.3, 70,
    'E · inspect the cart',
    'THE TRADER\u2019S CART',
    'Amphorae of southern wine, and one banded in the red of Rome. The goods come up the river now. The soldiers will not be far behind them.');

  /* ---------------- zones ---------------- */
  const zones = [
    { name: 'hall', bounds: { min: { x: 9, z: -9.5 }, max: { x: 26.5, z: -0.5 } } },
    { name: 'grove', bounds: { min: { x: -40, z: -37 }, max: { x: -16, z: -13 } } },
    { name: 'pens', bounds: { min: { x: 20, z: -30 }, max: { x: 40, z: -10 } } },
    { name: 'gate', bounds: { min: { x: -8, z: 34 }, max: { x: 8, z: 48 } } },
    { name: 'fields', bounds: { min: { x: -38, z: 58 }, max: { x: -14, z: 92 } } },
    { name: 'fields', bounds: { min: { x: 16, z: 58 }, max: { x: 46, z: 94 } } },
  ];
  function zoneAt(x, z, y) {
    if (y - terrainHeight(x, z) > 2.5) return 'rampart'; // feet are up on the walkway
    for (const zn of zones) {
      const b = zn.bounds;
      if (x >= b.min.x && x <= b.max.x && z >= b.min.z && z <= b.max.z) return zn.name;
    }
    if (Math.abs(x) < 10 && z > 34) return 'approach'; // the old road south
    if (Math.hypot(x, z) > 70) return 'forest';
    if ((x / WALL_RX) * (x / WALL_RX) + (z / WALL_RZ) * (z / WALL_RZ) < 1) return 'village';
    return 'approach';
  }

  /* ---------------- environment intensity trim ---------------- */
  scene.traverse(o => {
    const ms = Array.isArray(o.material) ? o.material : (o.material ? [o.material] : []);
    for (const m of ms) if ('envMapIntensity' in m) m.envMapIntensity = 0.35;
  });

  /* ---------------- per-frame update ---------------- */
  function update(dt, t) {
    for (const mx of mixers) mx.update(dt);
    // flames: 3-frame cycle + flicker
    for (const f of flameSprites) {
      const frame = Math.floor(t * 9 + f.phase * 3) % 3;
      f.tex.offset.x = frame / 3;
      const fl = 1 + Math.sin(t * 23 + f.phase * 9) * 0.12 + Math.sin(t * 41 + f.phase * 5) * 0.08;
      f.sprite.scale.set(1.1 * f.scale * fl, 1.5 * f.scale * (2 - fl) * 0.98, 1);
    }
    // fire lights flicker
    for (const fl2 of fireLights) {
      fl2.light.intensity = fl2.base * (0.86 + Math.sin(t * 17 + fl2.seed) * 0.09 + Math.sin(t * 43 + fl2.seed * 2) * 0.07);
    }
    // smoke: rise, expand, fade, drift with the wind
    for (const s of smokePuffs) {
      s.life += dt / 7;
      if (s.life > 1) {
        s.life = 0;
        s.seed = Math.random() * 10;
      }
      const l = s.life;
      s.sprite.position.set(
        s.x + Math.sin(l * 5 + s.seed) * 0.5 + l * 2.2, // wind pushes +x
        s.y + l * 5.5,
        s.z + Math.cos(l * 4 + s.seed) * 0.4
      );
      const sc = 0.8 + l * 3.2;
      s.sprite.scale.set(sc, sc, 1);
      s.sprite.material.opacity = 0.32 * (1 - l) * (l < 0.12 ? l / 0.12 : 1);
    }
    // mist drift
    for (const m of mists) {
      const px = m.x0 + Math.sin(t * m.speed + m.seed) * m.range;
      const pz = m.z0 + Math.cos(t * m.speed * 0.7 + m.seed * 1.3) * m.range * 0.6;
      m.sprite.position.x = px;
      m.sprite.position.z = pz;
      m.sprite.material.opacity = 0.09 + 0.05 * Math.sin(t * 0.3 + m.seed * 2);
    }
  }

  function nearestFireDist(x, z) {
    let best = 1e9;
    for (const f of fires) {
      const d = Math.hypot(x - f.x, z - f.z);
      if (d < best) best = d;
    }
    return best;
  }

  phase('sweeping the threshold…');

  return {
    colliders,
    spawn: { pos: new THREE.Vector3(0, 0, 95), yaw: 0 },
    interactables,
    zones,
    zoneAt,
    update,
    onEvent,
    groundHeight,
    nearestFireDist,
    forgePos,
    version: 'gaul-1',
  };
}
