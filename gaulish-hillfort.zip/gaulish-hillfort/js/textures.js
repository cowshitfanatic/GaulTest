// Procedural canvas texture factory — Dunon, a hillfort in Gaul (58 BCE).
// All textures: THREE.CanvasTexture, sRGB, RepeatWrapping, anisotropy 4.
// Seeded, deterministic. Sizes 256-512. No external images.
import * as THREE from 'three';

/* ---------------- seeded random + value noise ---------------- */

function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function makeNoise2D(seed) {
  const rand = mulberry32(seed);
  const p = Array.from({ length: 256 }, (_, i) => i);
  for (let i = 255; i > 0; i--) { const j = (rand() * (i + 1)) | 0; [p[i], p[j]] = [p[j], p[i]]; }
  const P = new Uint8Array(512);
  for (let i = 0; i < 512; i++) P[i] = p[i & 255];
  const val = (ix, iy) => P[(P[ix & 255] + iy) & 255] / 255;
  const fade = t => t * t * (3 - 2 * t);
  return (x, y) => {
    const ix = Math.floor(x), iy = Math.floor(y);
    const fx = x - ix, fy = y - iy;
    const a = val(ix, iy), b = val(ix + 1, iy), c = val(ix, iy + 1), d = val(ix + 1, iy + 1);
    const u = fade(fx), v = fade(fy);
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  };
}

function fbm(n, x, y, oct = 4, lac = 2, gain = 0.5) {
  let amp = 0.5, f = 1, s = 0, norm = 0;
  for (let i = 0; i < oct; i++) { s += amp * n(x * f, y * f); norm += amp; amp *= gain; f *= lac; }
  return s / norm;
}

/* ---------------- small helpers ---------------- */

function cv(w, h) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return [c, c.getContext('2d')];
}

function tex(c) {
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 4;
  return t;
}

function rgba(hex, a) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

function shade(hex, f) { // f<1 darken, f>1 lighten
  const n = parseInt(hex.slice(1), 16);
  const m = v => Math.max(0, Math.min(255, Math.round(v * f)));
  return `rgb(${m((n >> 16) & 255)},${m((n >> 8) & 255)},${m(n & 255)})`;
}

// per-pixel luminance grain over the whole canvas
function grain(ctx, w, h, rand, amt) {
  const id = ctx.getImageData(0, 0, w, h), d = id.data;
  for (let i = 0; i < d.length; i += 4) {
    const v = (rand() - 0.5) * 2 * amt;
    d[i] += v; d[i + 1] += v; d[i + 2] += v;
  }
  ctx.putImageData(id, 0, 0);
}

// soft irregular blotch
function blotch(ctx, x, y, r, color, alpha, rand, squash = 1) {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r);
  g.addColorStop(0, rgba(color, alpha));
  g.addColorStop(0.7, rgba(color, alpha * 0.45));
  g.addColorStop(1, rgba(color, 0));
  ctx.save();
  ctx.translate(x, y); ctx.scale(1, squash); ctx.translate(-x, -y);
  ctx.fillStyle = g;
  ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
  ctx.restore();
  void rand;
}

function vignette(ctx, w, h, amt = 0.22) {
  const g = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.35, w / 2, h / 2, Math.max(w, h) * 0.72);
  g.addColorStop(0, 'rgba(0,0,0,0)');
  g.addColorStop(1, `rgba(0,0,0,${amt})`);
  ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
}

/* ---------------- 1. thatch ---------------- */

export function thatch() {
  const W = 512, H = 512;
  const [c, x] = cv(W, H);
  const rand = mulberry32(2101), n = makeNoise2D(2102);
  x.fillStyle = '#8a713f'; x.fillRect(0, 0, W, H);
  // broad tonal bands (courses of reed)
  const id = x.getImageData(0, 0, W, H), d = id.data;
  for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
    const v = (fbm(n, i * 0.008, j * 0.02, 4) - 0.5) * 46;
    const k = (j * W + i) * 4;
    d[k] += v; d[k + 1] += v * 0.9; d[k + 2] += v * 0.7;
  }
  x.putImageData(id, 0, 0);
  // horizontal course seams (thatch laid in layers)
  for (let ly = 42; ly < H; ly += 64) {
    x.fillStyle = 'rgba(40,28,14,0.45)'; x.fillRect(0, ly, W, 3);
    x.fillStyle = 'rgba(230,200,140,0.20)'; x.fillRect(0, ly + 3, W, 2);
  }
  // thousands of individual straw strokes, mostly vertical-ish
  const straws = ['#a8894e', '#77592f', '#c2a05e', '#5f4a26', '#9c7f45'];
  for (let i = 0; i < 2600; i++) {
    x.strokeStyle = straws[(rand() * straws.length) | 0];
    x.globalAlpha = 0.25 + rand() * 0.45;
    x.lineWidth = 1 + rand() * 1.2;
    const sx = rand() * W, sy = rand() * H, l = 8 + rand() * 26;
    const a = Math.PI / 2 + (rand() - 0.5) * 0.7; // near-vertical, slight lean
    x.beginPath(); x.moveTo(sx, sy);
    x.lineTo(sx + Math.cos(a) * l, sy + Math.sin(a) * l);
    x.stroke();
  }
  x.globalAlpha = 1;
  // weathered dark patches (moss / age)
  for (let i = 0; i < 10; i++) blotch(x, rand() * W, rand() * H, 30 + rand() * 60, '#4a4028', 0.18, rand);
  grain(x, W, H, rand, 9);
  vignette(x, W, H, 0.16);
  return tex(c);
}

/* ---------------- 2. timber ---------------- */

export function timber(base = '#6e5233') {
  const W = 512, H = 512;
  const [c, x] = cv(W, H);
  const rand = mulberry32(2201), n = makeNoise2D(2202);
  x.fillStyle = base; x.fillRect(0, 0, W, H);
  // long horizontal grain tone
  const id = x.getImageData(0, 0, W, H), d = id.data;
  for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
    const v = (fbm(n, i * 0.004, j * 0.05, 4) - 0.5) * 36;
    const k = (j * W + i) * 4;
    d[k] += v; d[k + 1] += v * 0.85; d[k + 2] += v * 0.7;
  }
  x.putImageData(id, 0, 0);
  // grain lines
  for (let i = 0; i < 130; i++) {
    x.strokeStyle = rand() > 0.4 ? `rgba(40,26,14,${0.18 + rand() * 0.25})` : `rgba(190,150,100,${0.10 + rand() * 0.15})`;
    x.lineWidth = 0.8 + rand() * 1.6;
    const gy = rand() * H;
    x.beginPath(); x.moveTo(-10, gy);
    for (let px = 0; px <= W + 10; px += 32) x.lineTo(px, gy + (n(px * 0.02, gy * 0.05) - 0.5) * 14);
    x.stroke();
  }
  // knots
  for (let i = 0; i < 8; i++) {
    const kx = rand() * W, ky = rand() * H;
    for (let ring = 5; ring > 0; ring--) {
      x.strokeStyle = `rgba(42,28,15,${0.25 + ring * 0.06})`;
      x.lineWidth = 1.4;
      x.beginPath();
      x.ellipse(kx, ky, ring * 3.2, ring * 2.1, 0.3, 0, 7);
      x.stroke();
    }
    x.fillStyle = 'rgba(30,20,10,0.7)';
    x.beginPath(); x.ellipse(kx, ky, 3.4, 2.4, 0.3, 0, 7); x.fill();
  }
  // weathering streaks
  for (let i = 0; i < 12; i++) blotch(x, rand() * W, rand() * H, 20 + rand() * 50, '#3a2c18', 0.16, rand, 2.2);
  grain(x, W, H, rand, 8);
  vignette(x, W, H, 0.14);
  return tex(c);
}

/* ---------------- 3. wattle and daub ---------------- */

export function wattleDaub() {
  const W = 512, H = 512;
  const [c, x] = cv(W, H);
  const rand = mulberry32(2301), n = makeNoise2D(2302);
  x.fillStyle = '#b89a68'; x.fillRect(0, 0, W, H);
  // daub tone variation (hand-plastered lumps)
  const id = x.getImageData(0, 0, W, H), d = id.data;
  for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
    const v = (fbm(n, i * 0.02, j * 0.02, 4) - 0.5) * 34;
    const k = (j * W + i) * 4;
    d[k] += v; d[k + 1] += v * 0.9; d[k + 2] += v * 0.75;
  }
  x.putImageData(id, 0, 0);
  // horizontal wattle rods showing through in thin bands
  for (let ly = 30; ly < H; ly += 56) {
    const rodY = ly + (rand() - 0.5) * 6;
    x.fillStyle = 'rgba(88,62,34,0.55)';
    for (let seg = 0; seg < 26; seg++) {
      const sx = seg * 20 + (rand() - 0.5) * 6;
      x.beginPath(); x.ellipse(sx, rodY, 10, 2.6, 0, 0, 7); x.fill();
    }
    x.fillStyle = 'rgba(220,190,140,0.25)';
    x.fillRect(0, rodY - 4, W, 1.5);
  }
  // vertical withies — kept faint so the daub reads first
  for (let gx = 12; gx < W; gx += 64) {
    x.fillStyle = `rgba(96,68,36,${0.10 + rand() * 0.08})`;
    x.fillRect(gx + (rand() - 0.5) * 6, 0, 5, H);
  }
  // cracks in the daub
  for (let i = 0; i < 7; i++) {
    let px = rand() * W, py = rand() * H;
    x.strokeStyle = 'rgba(70,52,32,0.5)'; x.lineWidth = 1.2;
    x.beginPath(); x.moveTo(px, py);
    for (let k = 0; k < 18; k++) { px += (rand() - 0.5) * 18; py += rand() * 12; x.lineTo(px, py); }
    x.stroke();
  }
  // straw flecks in the plaster
  for (let i = 0; i < 220; i++) {
    x.strokeStyle = `rgba(210,180,120,${0.3 + rand() * 0.4})`;
    x.lineWidth = 1;
    const px = rand() * W, py = rand() * H, a = rand() * 6.3, l = 3 + rand() * 6;
    x.beginPath(); x.moveTo(px, py); x.lineTo(px + Math.cos(a) * l, py + Math.sin(a) * l); x.stroke();
  }
  // rain splash darkening near bottom
  const bg = x.createLinearGradient(0, H * 0.75, 0, H);
  bg.addColorStop(0, 'rgba(70,55,35,0)'); bg.addColorStop(1, 'rgba(70,55,35,0.30)');
  x.fillStyle = bg; x.fillRect(0, 0, W, H);
  grain(x, W, H, rand, 8);
  vignette(x, W, H, 0.12);
  return tex(c);
}

/* ---------------- 4. rampart stone (murus gallicus fill) ---------------- */

export function stoneWall() {
  const W = 512, H = 512;
  const [c, x] = cv(W, H);
  const rand = mulberry32(2401), n = makeNoise2D(2402);
  x.fillStyle = '#7d766b'; x.fillRect(0, 0, W, H);
  // dry-stone courses: irregular rounded stones
  const rows = 9, rh = H / rows;
  for (let r = 0; r < rows; r++) {
    let px = -rand() * 30;
    while (px < W + 20) {
      const sw = 38 + rand() * 52, sh = rh - 6 - rand() * 8;
      const sx = px + sw / 2, sy = r * rh + rh / 2;
      const v = (n(sx * 0.05, sy * 0.05) - 0.5) * 40;
      x.fillStyle = shade('#8a8378', 1 + v / 170);
      x.beginPath();
      x.ellipse(sx, sy, sw / 2 - 2, sh / 2, (rand() - 0.5) * 0.14, 0, 7);
      x.fill();
      // top-lit / bottom-shadowed for relief (kept soft: harsh rings read as wallpaper)
      x.strokeStyle = 'rgba(235,228,210,0.15)'; x.lineWidth = 2;
      x.beginPath(); x.ellipse(sx, sy - 1, sw / 2 - 3, sh / 2 - 1, 0, Math.PI * 1.05, Math.PI * 1.95); x.stroke();
      x.strokeStyle = 'rgba(25,22,18,0.26)'; x.lineWidth = 2.5;
      x.beginPath(); x.ellipse(sx, sy + 1, sw / 2 - 3, sh / 2 - 1, 0, Math.PI * 0.05, Math.PI * 0.95); x.stroke();
      // stone face texture: speckle + a crack or two
      for (let s = 0; s < 26; s++) {
        x.fillStyle = rand() > 0.5 ? 'rgba(255,250,235,0.08)' : 'rgba(20,18,15,0.10)';
        x.fillRect(sx + (rand() - 0.5) * sw * 0.8, sy + (rand() - 0.5) * sh * 0.7, 1.8, 1.8);
      }
      px += sw + 2 + rand() * 6;
    }
    // shadow line between courses
    x.fillStyle = 'rgba(20,18,15,0.35)'; x.fillRect(0, (r + 1) * rh - 2, W, 3);
  }
  // moss colonizing shaded joints
  for (let i = 0; i < 16; i++) blotch(x, rand() * W, rand() * H, 12 + rand() * 26, '#4a5a2e', 0.20, rand);
  grain(x, W, H, rand, 9);
  vignette(x, W, H, 0.16);
  return tex(c);
}

/* ---------------- 5. mud ground ---------------- */

export function mudGround(base = '#5e4a34') {
  const W = 512, H = 512;
  const [c, x] = cv(W, H);
  const rand = mulberry32(2501), n = makeNoise2D(2502);
  x.fillStyle = base; x.fillRect(0, 0, W, H);
  const id = x.getImageData(0, 0, W, H), d = id.data;
  for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
    const v = (fbm(n, i * 0.012, j * 0.012, 5) - 0.5) * 44;
    const k = (j * W + i) * 4;
    d[k] += v; d[k + 1] += v * 0.9; d[k + 2] += v * 0.8;
  }
  x.putImageData(id, 0, 0);
  // churned clods
  for (let i = 0; i < 380; i++) {
    const px = rand() * W, py = rand() * H, r = 2 + rand() * 7;
    x.fillStyle = rand() > 0.5 ? shade(base, 1.18) : shade(base, 0.78);
    x.globalAlpha = 0.5 + rand() * 0.4;
    x.beginPath(); x.ellipse(px, py, r, r * (0.5 + rand() * 0.5), rand() * 3, 0, 7); x.fill();
  }
  x.globalAlpha = 1;
  // puddle sheen spots
  for (let i = 0; i < 7; i++) blotch(x, rand() * W, rand() * H, 14 + rand() * 30, '#8a7a5e', 0.22, rand);
  // trampled straw
  for (let i = 0; i < 120; i++) {
    x.strokeStyle = `rgba(190,160,110,${0.2 + rand() * 0.3})`;
    x.lineWidth = 1;
    const px = rand() * W, py = rand() * H, a = rand() * 6.3, l = 4 + rand() * 9;
    x.beginPath(); x.moveTo(px, py); x.lineTo(px + Math.cos(a) * l, py + Math.sin(a) * l); x.stroke();
  }
  grain(x, W, H, rand, 9);
  vignette(x, W, H, 0.1);
  return tex(c);
}

/* ---------------- 6. grass ground ---------------- */

export function grassGround() {
  const W = 512, H = 512;
  const [c, x] = cv(W, H);
  const rand = mulberry32(2601), n = makeNoise2D(2602);
  x.fillStyle = '#5a6b34'; x.fillRect(0, 0, W, H);
  // late-summer patchiness: green / gold / bare
  const id = x.getImageData(0, 0, W, H), d = id.data;
  for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
    const m = fbm(n, i * 0.008, j * 0.008, 4);
    const v = (fbm(n, i * 0.05 + 40, j * 0.05, 3) - 0.5) * 36;
    const k = (j * W + i) * 4;
    // shift hue toward dry gold where m is high
    const gold = Math.max(0, m - 0.52) * 2.4;
    d[k] += v + gold * 40;
    d[k + 1] += v * 0.9 + gold * 22;
    d[k + 2] += v * 0.8 - gold * 18;
  }
  x.putImageData(id, 0, 0);
  // blade strokes
  const cols = ['#4a5c2a', '#6b7a38', '#8a8548', '#3d4e24'];
  for (let i = 0; i < 2400; i++) {
    x.strokeStyle = cols[(rand() * cols.length) | 0];
    x.globalAlpha = 0.3 + rand() * 0.5;
    x.lineWidth = 1;
    const px = rand() * W, py = rand() * H, l = 3 + rand() * 7, a = -Math.PI / 2 + (rand() - 0.5) * 1.2;
    x.beginPath(); x.moveTo(px, py); x.lineTo(px + Math.cos(a) * l, py + Math.sin(a) * l); x.stroke();
  }
  x.globalAlpha = 1;
  // bare earth patches
  for (let i = 0; i < 8; i++) blotch(x, rand() * W, rand() * H, 18 + rand() * 40, '#6b573c', 0.30, rand);
  grain(x, W, H, rand, 8);
  vignette(x, W, H, 0.1);
  return tex(c);
}

/* ---------------- 7. dirt road ---------------- */

export function dirtRoad() {
  const W = 256, H = 512;
  const [c, x] = cv(W, H);
  const rand = mulberry32(2701), n = makeNoise2D(2702);
  x.fillStyle = '#7a6244'; x.fillRect(0, 0, W, H);
  const id = x.getImageData(0, 0, W, H), d = id.data;
  for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
    const v = (fbm(n, i * 0.02, j * 0.008, 4) - 0.5) * 36;
    const k = (j * W + i) * 4;
    d[k] += v; d[k + 1] += v * 0.9; d[k + 2] += v * 0.8;
  }
  x.putImageData(id, 0, 0);
  // two wheel ruts running along the road (v axis)
  for (const rx of [W * 0.30, W * 0.70]) {
    const g = x.createLinearGradient(rx - 26, 0, rx + 26, 0);
    g.addColorStop(0, 'rgba(60,46,30,0)');
    g.addColorStop(0.5, 'rgba(60,46,30,0.42)');
    g.addColorStop(1, 'rgba(60,46,30,0)');
    x.fillStyle = g; x.fillRect(rx - 26, 0, 52, H);
    // rut edge highlight
    x.fillStyle = 'rgba(200,170,130,0.18)';
    x.fillRect(rx - 27, 0, 3, H); x.fillRect(rx + 24, 0, 3, H);
  }
  // center grass tuft strip
  for (let j = 0; j < H; j += 6) {
    if (rand() < 0.75) {
      x.strokeStyle = `rgba(110,120,60,${0.35 + rand() * 0.35})`;
      x.lineWidth = 1.4;
      const px = W / 2 + (rand() - 0.5) * 26, py = j + rand() * 6;
      x.beginPath(); x.moveTo(px, py);
      x.lineTo(px + (rand() - 0.5) * 8, py - 5 - rand() * 6); x.stroke();
    }
  }
  // foot-worn pebbles
  for (let i = 0; i < 160; i++) {
    x.fillStyle = rand() > 0.5 ? 'rgba(150,130,105,0.7)' : 'rgba(70,55,38,0.7)';
    x.beginPath();
    x.ellipse(rand() * W, rand() * H, 1 + rand() * 2.4, 1 + rand() * 1.8, rand() * 3, 0, 7);
    x.fill();
  }
  grain(x, W, H, rand, 9);
  return tex(c);
}

/* ---------------- 8. crop rows ---------------- */

export function cropRows() {
  const W = 512, H = 512;
  const [c, x] = cv(W, H);
  const rand = mulberry32(2801), n = makeNoise2D(2802);
  x.fillStyle = '#6a5a38'; x.fillRect(0, 0, W, H);
  // ridged earth: alternating light/dark bands along x
  const rows = 8, rw = W / rows;
  for (let r = 0; r < rows; r++) {
    const g = x.createLinearGradient(r * rw, 0, (r + 1) * rw, 0);
    g.addColorStop(0, 'rgba(52,40,24,0.55)');
    g.addColorStop(0.5, 'rgba(190,160,110,0.30)');
    g.addColorStop(1, 'rgba(52,40,24,0.55)');
    x.fillStyle = g; x.fillRect(r * rw, 0, rw, H);
  }
  // soil noise
  const id = x.getImageData(0, 0, W, H), d = id.data;
  for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
    const v = (fbm(n, i * 0.03, j * 0.03, 3) - 0.5) * 30;
    const k = (j * W + i) * 4;
    d[k] += v; d[k + 1] += v * 0.9; d[k + 2] += v * 0.8;
  }
  x.putImageData(id, 0, 0);
  // crop lines: wheat-ish tufts along ridge tops
  for (let r = 0; r < rows; r++) {
    const cxp = (r + 0.5) * rw;
    for (let j = 4; j < H; j += 10) {
      if (rand() < 0.9) {
        const px = cxp + (rand() - 0.5) * 14, py = j + (rand() - 0.5) * 8;
        const hgt = 10 + rand() * 12;
        const gold = rand();
        x.strokeStyle = gold < 0.6 ? '#b89a4e' : (gold < 0.85 ? '#8a7a38' : '#6b7a38');
        x.globalAlpha = 0.75;
        for (let s = -2; s <= 2; s++) {
          x.lineWidth = 1.2;
          x.beginPath(); x.moveTo(px, py);
          x.lineTo(px + s * 2 + (rand() - 0.5) * 3, py - hgt); x.stroke();
        }
        // seed head
        x.fillStyle = '#c8a85e'; x.globalAlpha = 0.85;
        x.beginPath(); x.ellipse(px, py - hgt, 2.4, 3.6, 0, 0, 7); x.fill();
      }
    }
  }
  x.globalAlpha = 1;
  grain(x, W, H, rand, 8);
  vignette(x, W, H, 0.1);
  return tex(c);
}

/* ---------------- 9. flame (3-frame horizontal strip for animated sprites) ---------------- */

export function flameStrip() {
  const FW = 64, FH = 64, FR = 3;
  const [c, x] = cv(FW * FR, FH);
  const rand = mulberry32(2901);
  for (let f = 0; f < FR; f++) {
    const ox = f * FW;
    // flame body: stacked radial blobs, tall and licking
    const blobs = [
      [32, 50, 17, '#ff7a1e', 0.95], [32, 40, 14, '#ffa53e', 0.95],
      [32, 30, 11, '#ffd76e', 0.95], [32 + (rand() - 0.5) * 10, 20, 8, '#ffefb0', 0.9],
      [32 + (rand() - 0.5) * 16, 12, 6, '#fff6d8', 0.85]
    ];
    blobs.forEach(([bx, by, br, col, a]) => {
      const g = x.createRadialGradient(ox + bx, by, 0, ox + bx, by, br);
      g.addColorStop(0, rgba(col, a));
      g.addColorStop(0.6, rgba(col, a * 0.55));
      g.addColorStop(1, rgba(col, 0));
      x.fillStyle = g;
      x.save();
      x.translate(ox + bx, by); x.scale(0.75 + rand() * 0.2, 1.35); x.translate(-(ox + bx), -by);
      x.beginPath(); x.arc(ox + bx, by, br, 0, 7); x.fill();
      x.restore();
    });
    // deep orange base glow
    const g0 = x.createRadialGradient(ox + 32, 56, 0, ox + 32, 56, 24);
    g0.addColorStop(0, 'rgba(255,90,20,0.8)');
    g0.addColorStop(1, 'rgba(255,90,20,0)');
    x.fillStyle = g0;
    x.beginPath(); x.arc(ox + 32, 56, 24, 0, 7); x.fill();
  }
  const t = tex(c);
  t.wrapS = THREE.ClampToEdgeWrapping; // strip frames must not bleed
  t.wrapT = THREE.ClampToEdgeWrapping;
  return t;
}

/* ---------------- 10. smoke puff ---------------- */

export function smoke() {
  const W = 128, H = 128;
  const [c, x] = cv(W, H);
  const rand = mulberry32(3001), n = makeNoise2D(3002);
  const cxp = W / 2, cyp = H / 2;
  // irregular soft puff built from overlapping blobs
  for (let i = 0; i < 22; i++) {
    const a = rand() * 6.3, rr = rand() * 34;
    const px = cxp + Math.cos(a) * rr, py = cyp + Math.sin(a) * rr;
    const br = 12 + rand() * 20;
    const dens = 0.10 + (1 - rr / 40) * 0.14;
    const g = x.createRadialGradient(px, py, 0, px, py, br);
    g.addColorStop(0, `rgba(200,198,195,${dens})`);
    g.addColorStop(1, 'rgba(200,198,195,0)');
    x.fillStyle = g;
    x.beginPath(); x.arc(px, py, br, 0, 7); x.fill();
  }
  // noise-erode edges so it never reads as a hard circle
  const id = x.getImageData(0, 0, W, H), d = id.data;
  for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
    const dx = i - cxp, dy = j - cyp, rr = Math.hypot(dx, dy) / 56;
    const m = fbm(n, i * 0.05, j * 0.05, 3);
    const k = (j * W + i) * 4;
    if (rr + (m - 0.5) * 0.9 > 1.0) d[k + 3] = 0;
  }
  x.putImageData(id, 0, 0);
  return tex(c);
}

/* ---------------- 11. ground mist ---------------- */

export function mist() {
  const W = 256, H = 128;
  const [c, x] = cv(W, H);
  const rand = mulberry32(3101), n = makeNoise2D(3102);
  // wide low band of soft vapor
  for (let i = 0; i < 40; i++) {
    const px = rand() * W, py = H * 0.35 + rand() * H * 0.4;
    const br = 18 + rand() * 34;
    const g = x.createRadialGradient(px, py, 0, px, py, br);
    g.addColorStop(0, `rgba(210,208,220,${0.10 + rand() * 0.10})`);
    g.addColorStop(1, 'rgba(210,208,220,0)');
    x.fillStyle = g;
    x.save();
    x.translate(px, py); x.scale(1.8, 0.7); x.translate(-px, -py);
    x.beginPath(); x.arc(px, py, br, 0, 7); x.fill();
    x.restore();
  }
  // fade top and bottom edges + side edges
  const id = x.getImageData(0, 0, W, H), d = id.data;
  for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
    const ex = Math.min(i, W - i) / (W * 0.25);
    const ey = Math.min(j, H - j) / (H * 0.3);
    const m = Math.min(1, ex, ey) * (0.6 + fbm(n, i * 0.03, j * 0.03, 3) * 0.6);
    const k = (j * W + i) * 4;
    d[k + 3] = Math.min(d[k + 3], d[k + 3] * m);
  }
  x.putImageData(id, 0, 0);
  return tex(c);
}

/* ---------------- 12. charred wood (fire pit / forge) ---------------- */

export function charred() {
  const W = 256, H = 256;
  const [c, x] = cv(W, H);
  const rand = mulberry32(3201), n = makeNoise2D(3202);
  x.fillStyle = '#211a14'; x.fillRect(0, 0, W, H);
  const id = x.getImageData(0, 0, W, H), d = id.data;
  for (let j = 0; j < H; j++) for (let i = 0; i < W; i++) {
    const v = (fbm(n, i * 0.02, j * 0.02, 4) - 0.5) * 40;
    const k = (j * W + i) * 4;
    d[k] += v; d[k + 1] += v * 0.9; d[k + 2] += v * 0.85;
  }
  x.putImageData(id, 0, 0);
  // ember cracks: glowing fissures
  for (let i = 0; i < 14; i++) {
    let px = rand() * W, py = rand() * H;
    x.strokeStyle = `rgba(255,${110 + (rand() * 60 | 0)},30,${0.35 + rand() * 0.4})`;
    x.lineWidth = 1 + rand() * 2;
    x.beginPath(); x.moveTo(px, py);
    for (let k = 0; k < 10; k++) { px += (rand() - 0.5) * 30; py += (rand() - 0.5) * 30; x.lineTo(px, py); }
    x.stroke();
  }
  // ash dusting
  for (let i = 0; i < 200; i++) {
    x.fillStyle = `rgba(180,175,165,${0.08 + rand() * 0.15})`;
    x.fillRect(rand() * W, rand() * H, 1.5, 1.5);
  }
  grain(x, W, H, rand, 8);
  return tex(c);
}

/* ---------------- 17. procedural dusk sky (equirectangular) ---------------- */
/* Replaces the photo sky: art-directed late-summer dusk. Sun azimuth matches
   the directional light at (-70, 15, 28): u = atan2(28,-70)/2PI + 0.5. */

export function duskSky() {
  const W = 1024, H = 512;
  const [c, x] = cv(W, H);
  const rand = mulberry32(777), n = makeNoise2D(778);
  // vertical gradient: indigo zenith -> warm horizon -> dark ground haze
  const g = x.createLinearGradient(0, 0, 0, H);
  g.addColorStop(0.00, '#10162e');
  g.addColorStop(0.24, '#232c52');
  g.addColorStop(0.39, '#4a4260');
  g.addColorStop(0.47, '#8a5a4a');
  g.addColorStop(0.50, '#c47a44');
  g.addColorStop(0.56, '#3a2a28');
  g.addColorStop(1.00, '#171216');
  x.fillStyle = g; x.fillRect(0, 0, W, H);
  // sun glow at u=0.939 (matches directional light azimuth), just above horizon
  const sx = 0.939 * W, sy = 0.438 * H;
  for (const ox of [0, -W, W]) {
    const rg = x.createRadialGradient(sx + ox, sy, 8, sx + ox, sy, 200);
    rg.addColorStop(0, 'rgba(255,224,170,0.95)');
    rg.addColorStop(0.25, 'rgba(255,180,110,0.55)');
    rg.addColorStop(1, 'rgba(255,150,90,0)');
    x.fillStyle = rg; x.fillRect(0, 0, W, H);
  }
  // warm wash along the whole horizon band so it never goes grey
  const hz = x.createLinearGradient(0, H * 0.42, 0, H * 0.56);
  hz.addColorStop(0, 'rgba(190,110,70,0)');
  hz.addColorStop(0.5, 'rgba(210,130,80,0.35)');
  hz.addColorStop(1, 'rgba(190,110,70,0)');
  x.fillStyle = hz; x.fillRect(0, H * 0.42, W, H * 0.14);
  // thin dusk cloud bands, stretched horizontally, darker violet
  for (let b = 0; b < 9; b++) {
    const by = 40 + rand() * 180, bh = 6 + rand() * 16;
    for (let i = 0; i < W; i += 4) {
      const w = fbm(n, i * 0.008, b * 3.7, 3);
      if (w > 0.52) {
        x.fillStyle = `rgba(40,36,66,${(w - 0.52) * 0.9})`;
        x.fillRect(i, by + (w - 0.5) * 22, 4, bh);
      }
    }
  }
  // faint early stars up top
  for (let i = 0; i < 160; i++) {
    const px = rand() * W, py = rand() * H * 0.3;
    x.fillStyle = `rgba(220,225,255,${0.12 + rand() * 0.3})`;
    x.fillRect(px, py, 1.3, 1.3);
  }
  grain(x, W, H, rand, 6);
  const t = tex(c);
  t.wrapS = THREE.RepeatWrapping; t.wrapT = THREE.ClampToEdgeWrapping;
  return t;
}
