/**
 * Ambience — fully procedural WebAudio soundscape for Dunon (Gaul, 58 BCE).
 *
 * Zero audio files. Everything is synthesized: noise buffers, oscillators,
 * filters, LFOs, and scheduled one-shot events.
 *
 * Architecture:
 *   layers (wind, crickets, fire crackle) ─┐
 *   event one-shots (clank, bark, caw) ─────┤
 *                                           ▼
 *                                      masterGain → compressor → destination
 *
 * Zone changes crossfade the bed character with smooth ramps. Proximity
 * inputs (fire distance, forge nearness) come from main.js each frame.
 */

const ZONE_DEFAULTS = {
  // Per-zone bed character. Gains multiply the layer base levels.
  approach: { wind: 1.00, windFreq: 320, cricket: 0.80, hush: 0.0 },
  gate:     { wind: 0.90, windFreq: 300, cricket: 0.45, hush: 0.0 },
  village:  { wind: 0.70, windFreq: 280, cricket: 0.35, hush: 0.0 },
  hall:     { wind: 0.35, windFreq: 220, cricket: 0.10, hush: 0.4 },
  grove:    { wind: 0.45, windFreq: 200, cricket: 0.55, hush: 0.7 },
  pens:     { wind: 0.75, windFreq: 300, cricket: 0.40, hush: 0.0 },
  rampart:  { wind: 1.35, windFreq: 420, cricket: 0.25, hush: 0.0 },
  fields:   { wind: 1.10, windFreq: 360, cricket: 1.00, hush: 0.0 },
  forest:   { wind: 0.60, windFreq: 180, cricket: 0.30, hush: 0.5 },
};

const BASE = {
  wind: 0.11,
  cricket: 0.016,
  crackle: 0.10,
};

export class Ambience {
  constructor() {
    this.ctx = null;
    this.muted = false;
    this._started = false;
    this._zone = 'approach';
    this._fireDist = 999;   // meters to nearest fire; drives crackle
    this._forgeNear = false;
    this._timers = [];
  }

  // ------------------------------------------------------------------ setup

  /** Creates the AudioContext and builds the graph. Call from a user gesture. */
  start() {
    if (this._started) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this._started = true;

    const ctx = this.ctx;
    this.master = ctx.createGain();
    this.master.gain.value = 0.9;
    this.compressor = ctx.createDynamicsCompressor();
    this.compressor.threshold.value = -18;
    this.compressor.knee.value = 24;
    this.compressor.ratio.value = 8;
    this.compressor.attack.value = 0.004;
    this.compressor.release.value = 0.24;
    this.master.connect(this.compressor);
    this.compressor.connect(ctx.destination);

    this._buildWind();
    this._buildCricketBus();
    this._buildCrackle();
    this._startSchedulers();
    this.setZone(this._zone);
  }

  _noiseBuffer(seconds, brown = false) {
    const ctx = this.ctx;
    const len = Math.floor(ctx.sampleRate * seconds);
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    if (!brown) {
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    } else {
      let last = 0;
      for (let i = 0; i < len; i++) {
        const w = Math.random() * 2 - 1;
        last = (last + 0.02 * w) / 1.02;
        d[i] = last * 3.5;
      }
    }
    return buf;
  }

  _loopNoise(brown, seconds) {
    const src = this.ctx.createBufferSource();
    src.buffer = this._noiseBuffer(seconds, brown);
    src.loop = true;
    return src;
  }

  // ---------------------------------------------------------------- layers

  _buildWind() {
    // Late-summer dusk wind over the hill: looped brown noise through a
    // lowpass, with a slow LFO wandering the cutoff so gusts come and go.
    const ctx = this.ctx;
    const src = this._loopNoise(true, 5);
    this.windFilter = ctx.createBiquadFilter();
    this.windFilter.type = 'lowpass';
    this.windFilter.frequency.value = 320;
    this.windFilter.Q.value = 0.6;
    this.windGain = ctx.createGain();
    this.windGain.gain.value = BASE.wind;
    src.connect(this.windFilter);
    this.windFilter.connect(this.windGain);
    this.windGain.connect(this.master);
    src.start();

    // Gust LFO on the filter: ~23s cycle.
    const lfo = ctx.createOscillator();
    lfo.type = 'sine';
    lfo.frequency.value = 0.043;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = 130;
    lfo.connect(lfoGain);
    lfoGain.connect(this.windFilter.frequency);
    lfo.start();

    // Slower swell on the gain itself.
    const lfo2 = ctx.createOscillator();
    lfo2.frequency.value = 0.071;
    const g2 = ctx.createGain();
    g2.gain.value = BASE.wind * 0.45;
    lfo2.connect(g2);
    g2.connect(this.windGain.gain);
    lfo2.start();
  }

  _buildCricketBus() {
    // Dusk crickets: a bus whose gain is zone-driven; individual chirps are
    // scheduled (see _startSchedulers). High shelf keeps them airy.
    const ctx = this.ctx;
    this.cricketBus = ctx.createGain();
    this.cricketBus.gain.value = 0;
    const hs = ctx.createBiquadFilter();
    hs.type = 'highshelf';
    hs.frequency.value = 3800;
    hs.gain.value = 6;
    this.cricketBus.connect(hs);
    hs.connect(this.master);
  }

  _cricketChirp() {
    if (!this._started || this.muted) return;
    const ctx = this.ctx;
    const t = ctx.currentTime + 0.02;
    const f = 4100 + Math.random() * 700;
    // A chirp: ~90ms of 25Hz-pulsed tone, random pan.
    const o = ctx.createOscillator();
    o.type = 'sine';
    o.frequency.value = f;
    const am = ctx.createGain();
    am.gain.value = 0;
    // pulse envelope via square-ish LFO built from scheduled ramps
    const pulses = 3 + (Math.random() * 3 | 0);
    for (let p = 0; p < pulses; p++) {
      const pt = t + p * 0.045;
      am.gain.setValueAtTime(0.0001, pt);
      am.gain.exponentialRampToValueAtTime(0.5, pt + 0.008);
      am.gain.exponentialRampToValueAtTime(0.0001, pt + 0.04);
    }
    const g = ctx.createGain();
    g.gain.value = 0.5;
    const pan = ctx.createStereoPanner();
    pan.pan.value = Math.random() * 1.7 - 0.85;
    o.connect(am); am.connect(g); g.connect(pan); pan.connect(this.cricketBus);
    const dur = pulses * 0.045 + 0.1;
    o.start(t); o.stop(t + dur);
  }

  _buildCrackle() {
    // Fire crackle: looped white noise through a highpass (the bed hiss),
    // plus scheduled pops. Gain is driven by proximity to the nearest fire.
    const ctx = this.ctx;
    const src = this._loopNoise(false, 2);
    const hp = ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.value = 1400;
    this.crackleGain = ctx.createGain();
    this.crackleGain.gain.value = 0;
    src.connect(hp); hp.connect(this.crackleGain); this.crackleGain.connect(this.master);
    src.start();
  }

  _cracklePop() {
    if (!this._started || this.muted) return;
    const ctx = this.ctx;
    const t = ctx.currentTime + 0.02;
    const src = ctx.createBufferSource();
    src.buffer = this._noiseBuffer(0.09, false);
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 900 + Math.random() * 2600;
    bp.Q.value = 2.5;
    const g = ctx.createGain();
    const peak = 0.25 + Math.random() * 0.75;
    g.gain.setValueAtTime(peak, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.05 + Math.random() * 0.06);
    const pan = ctx.createStereoPanner();
    pan.pan.value = Math.random() * 1.2 - 0.6;
    src.connect(bp); bp.connect(g); g.connect(pan); pan.connect(this.crackleGain);
    src.start(t); src.stop(t + 0.2);
  }

  // ------------------------------------------------------------- schedulers

  _every(ms, fn) {
    const id = setInterval(() => {
      if (this.muted || !this._started) return;
      fn();
    }, ms);
    this._timers.push(id);
  }

  _startSchedulers() {
    // Crickets: sparse chirps, density scaled by zone level.
    this._every(650, () => {
      const lvl = (ZONE_DEFAULTS[this._zone] || ZONE_DEFAULTS.approach).cricket;
      if (Math.random() < lvl * 0.8) this._cricketChirp();
      if (Math.random() < lvl * 0.25) setTimeout(() => this._cricketChirp(), 180);
    });
    // Fire pops: only audible near a fire (crackleGain > ~0).
    this._every(900, () => {
      if (this.crackleGain.gain.value > 0.008 && Math.random() < 0.75) this._cracklePop();
    });
    // Forge hammer: rhythmic work-song of the smith, only when near.
    this._every(1400, () => {
      if (this._forgeNear && Math.random() < 0.42) this._clank();
    });
    // Distant dog: the village keeps one. Sparse.
    this._every(9000, () => {
      if ((this._zone === 'village' || this._zone === 'gate') && Math.random() < 0.30) this._bark();
    });
    // Crows in the grove: the druid's neighbors.
    this._every(11000, () => {
      if (this._zone === 'grove' && Math.random() < 0.45) this._caw();
      else if (this._zone === 'forest' && Math.random() < 0.15) this._caw();
    });
  }

  // ------------------------------------------------------------- one-shots

  _noiseBurst({ dur, filterType, freq, q = 1, gain, decay = 0.02, dest }) {
    const ctx = this.ctx;
    const t = ctx.currentTime;
    const src = ctx.createBufferSource();
    src.buffer = this._noiseBuffer(Math.min(dur + 0.1, 2), false);
    const f = ctx.createBiquadFilter();
    f.type = filterType; f.frequency.value = freq; f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur + decay);
    src.connect(f); f.connect(g); g.connect(dest || this.master);
    src.start(t); src.stop(t + dur + decay + 0.05);
  }

  _clank() {
    // Smith's hammer on hot iron: bright metallic strike + faint ring.
    this._noiseBurst({ dur: 0.05, filterType: 'bandpass', freq: 2400, q: 3, gain: 0.10 });
    const ctx = this.ctx;
    const t = ctx.currentTime;
    [1244, 1867, 830].forEach((f, i) => {
      const o = ctx.createOscillator();
      o.type = 'triangle';
      o.frequency.value = f * (1 + (Math.random() - 0.5) * 0.015);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.035 / (i + 1), t);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.35 + i * 0.08);
      o.connect(g); g.connect(this.master);
      o.start(t); o.stop(t + 0.7);
    });
  }

  _bark() {
    // One distant dog: 2-3 short low barks, muffled by distance.
    const ctx = this.ctx;
    const t0 = ctx.currentTime + 0.05;
    const n = 2 + (Math.random() * 2 | 0);
    for (let i = 0; i < n; i++) {
      const t = t0 + i * (0.28 + Math.random() * 0.12);
      const o = ctx.createOscillator();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(210, t);
      o.frequency.exponentialRampToValueAtTime(95, t + 0.11);
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass'; lp.frequency.value = 700;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.06, t + 0.015);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.14);
      const pan = ctx.createStereoPanner();
      pan.pan.value = -0.5 + Math.random() * 0.3;
      o.connect(lp); lp.connect(g); g.connect(pan); pan.connect(this.master);
      o.start(t); o.stop(t + 0.2);
    }
  }

  _caw() {
    // Crow: 2-4 harsh descending calls from the grove oaks.
    const ctx = this.ctx;
    const t0 = ctx.currentTime + 0.05;
    const n = 2 + (Math.random() * 3 | 0);
    for (let i = 0; i < n; i++) {
      const t = t0 + i * (0.34 + Math.random() * 0.15);
      const o = ctx.createOscillator();
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(1050 + Math.random() * 150, t);
      o.frequency.exponentialRampToValueAtTime(620, t + 0.16);
      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass'; bp.frequency.value = 1400; bp.Q.value = 1.6;
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.0001, t);
      g.gain.exponentialRampToValueAtTime(0.045, t + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.2);
      const pan = ctx.createStereoPanner();
      pan.pan.value = 0.3 + Math.random() * 0.4;
      o.connect(bp); bp.connect(g); g.connect(pan); pan.connect(this.master);
      o.start(t); o.stop(t + 0.26);
    }
  }

  // ------------------------------------------------------------------ zones

  /**
   * Crossfade the bed character for a zone.
   * Zones: approach, gate, village, grove, pens, rampart, fields, forest, hall.
   */
  setZone(name) {
    this._zone = name;
    if (!this._started) return;
    const z = ZONE_DEFAULTS[name] || ZONE_DEFAULTS.approach;
    const t = this.ctx.currentTime;
    const TC = 1.6;
    // hush: grove/forest/hall pull the wind down and soften the air.
    const hushCut = 1 - z.hush * 0.45;
    this.windGain.gain.setTargetAtTime(BASE.wind * z.wind * hushCut, t, TC);
    this.windFilter.frequency.setTargetAtTime(z.windFreq, t, TC);
    this.cricketBus.gain.setTargetAtTime(BASE.cricket * z.cricket, t, TC);
    this._updateCrackle();
  }

  /** main.js calls this every frame with the distance to the nearest fire. */
  setFireDist(d) {
    this._fireDist = d;
    this._updateCrackle();
  }

  setForgeNear(v) { this._forgeNear = v; }

  _updateCrackle() {
    if (!this._started) return;
    // Full crackle within 2m, fading out by ~14m.
    const d = this._fireDist;
    const lvl = d >= 14 ? 0 : BASE.crackle * Math.pow(1 - d / 14, 1.6);
    this.crackleGain.gain.setTargetAtTime(lvl, this.ctx.currentTime, 0.6);
  }

  // ------------------------------------------------------------------ mute

  /** Toggles mute. Returns the new muted state. */
  toggleMute() {
    this.muted = !this.muted;
    if (this._started) {
      this.master.gain.setTargetAtTime(this.muted ? 0 : 0.9, this.ctx.currentTime, 0.08);
    }
    return this.muted;
  }

  dispose() {
    this._timers.forEach(clearInterval);
    this._timers = [];
    if (this.ctx) this.ctx.close().catch(() => {});
    this._started = false;
  }
}
