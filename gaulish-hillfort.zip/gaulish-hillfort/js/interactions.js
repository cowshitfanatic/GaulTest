import * as THREE from 'three';

/**
 * Interactions — center-screen raycast targeting, prompt display, E-key use,
 * and the objective system.
 *
 * Contract with world.js: getInteractables() returns the live array of
 *   { id, proxy: Object3D, getPrompt(), canUse(), use() }
 * Interactables may be enabled/disabled (e.g. chamber door locked/unlocked)
 * or even change proxies over time; we re-read the array every frame.
 *
 * Constructor opts (second argument object after the positional ones is
 * accepted for forward-compatibility, but the primary wiring is via opts):
 *   new Interactions(camera, domElement, getInteractables, ui, {
 *     onToggleFlashlight,   // F key
 *     onToggleMute,          // M key
 *     onObjectiveEvent,      // (name) — main.js wires world/audio side effects
 *   })
 */

const USE_RANGE = 3.2;   // max interact distance, meters
const FADE_MS = 450;     // objective text fade transition

export class Interactions {
  /**
   * @param {THREE.Camera} camera
   * @param {HTMLElement} domElement - listens for keydown here (document-level)
   * @param {() => Array} getInteractables - live interactable list
   * @param {{ promptEl: HTMLElement, objectiveEl: HTMLElement }} ui
   * @param {object} [opts] - { onToggleFlashlight, onToggleMute, onObjectiveEvent }
   */
  constructor(camera, domElement, getInteractables, ui, opts = {}) {
    this.camera = camera;
    this.domElement = domElement;
    this.getInteractables = getInteractables;
    this.ui = ui;
    this.onToggleFlashlight = opts.onToggleFlashlight || (() => {});
    this.onToggleMute = opts.onToggleMute || (() => {});
    this.onObjectiveEvent = opts.onObjectiveEvent || (() => {});

    this._raycaster = new THREE.Raycaster();
    this._raycaster.far = USE_RANGE;
    this._center = new THREE.Vector2(0, 0); // NDC center of screen
    this._current = null; // currently targeted interactable
    this._currentDist = 0;
    this._occluders = opts.occluders || []; // Box3 solids: prompt suppressed through walls
    this._occlHit = new THREE.Vector3();

    // Prompt visibility is driven by the .on class (CSS opacity transition).
    // (No inline display manipulation — styles.css owns the visuals.)

    this._onKeyDown = (e) => {
      if (e.repeat) return;
      if (e.code === 'KeyE') {
        if (this._current && this._current.canUse()) {
          this._current.use();
        }
      } else if (e.code === 'KeyF') {
        this.onToggleFlashlight();
      } else if (e.code === 'KeyM') {
        this.onToggleMute();
      }
    };
    document.addEventListener('keydown', this._onKeyDown);
  }

  /**
   * Write a new objective line with a subtle fade. Consecutive calls while
   * empty or identical are no-ops to avoid visual noise.
   */
  setObjective(text) {
    const el = this.ui.objectiveEl;
    if (!el) return;
    if (el.textContent === text) return;
    const doSwap = () => {
      el.textContent = text;
      el.style.opacity = '1';
    };
    // Fade out, swap, fade in. If reduced-motion or the element isn't
    // transitioned, this still completes cleanly.
    el.style.transition = `opacity ${FADE_MS}ms ease`;
    el.style.opacity = '0';
    clearTimeout(this._objectiveTimer);
    this._objectiveTimer = setTimeout(doSwap, FADE_MS);
  }

  /**
   * Objective event hook for main.js. Unused in this build (no quest system);
   * kept for API compatibility with the interactions contract.
   */
  triggerObjectiveEvent(name) {
    this.onObjectiveEvent(name);
  }

  /** Collect world proxies from every interactable into a flat list. */
  _collectProxies(interactables) {
    const out = [];
    for (const it of interactables) {
      if (!it || !it.proxy) continue;
      // Tag the proxy so we can map an intersection back to its interactable.
      it.proxy.userData.__interactable = it;
      out.push(it.proxy);
    }
    return out;
  }

  update(_dt) {
    const interactables = this.getInteractables() || [];
    const promptEl = this.ui.promptEl;
    this._current = null;

    if (interactables.length > 0) {
      this._raycaster.setFromCamera(this._center, this.camera);
      // Proxies are Object3D groups/meshes; recursive intersect covers children.
      const hits = this._raycaster.intersectObjects(
        this._collectProxies(interactables), true
      );
      for (const hit of hits) {
        let obj = hit.object;
        // Walk up to the tagged proxy root.
        while (obj && !obj.userData.__interactable) obj = obj.parent;
        const it = obj ? obj.userData.__interactable : null;
        if (it && it.canUse()) {
          this._current = it;
          this._currentDist = hit.distance;
          break;
        }
      }
    }

    // Occlusion: a solid wall between camera and proxy suppresses the prompt.
    // (A solid that *contains* the proxy itself — e.g. the cart's own body —
    // can never occlude it.)
    if (this._current && this._occluders.length) {
      const ray = this._raycaster.ray;
      const proxyPos = this._current.proxy.getWorldPosition(this._occlHit).clone();
      for (const b of this._occluders) {
        if (!b || !b.isBox3) continue;
        if (b.containsPoint(ray.origin)) continue; // camera inside this solid
        if (b.containsPoint(proxyPos)) continue; // proxy inside this solid
        const p = ray.intersectBox(b, this._occlHit);
        if (p && p.distanceTo(ray.origin) < this._currentDist - 0.3) {
          this._current = null;
          break;
        }
      }
    }

    if (promptEl) {
      if (this._current) {
        const text = this._current.getPrompt();
        if (promptEl.textContent !== text) promptEl.textContent = text;
        promptEl.classList.add('on');
      } else {
        promptEl.classList.remove('on');
      }
    }
  }

  dispose() {
    document.removeEventListener('keydown', this._onKeyDown);
    clearTimeout(this._objectiveTimer);
  }
}
