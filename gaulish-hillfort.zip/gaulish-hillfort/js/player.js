import * as THREE from 'three';

/**
 * Player — first-person controller for Dunon.
 *
 * Same design as the lab build (pointer-lock YXZ look, WASD/arrows, Shift
 * sprint, exponential velocity, axis-separated swept AABB vs Box3, 0.15m
 * sub-steps, 1.65m eye), plus:
 * - Uneven ground: feet ride world.groundHeight(x, z) (terrain, the earthen
 *   ramp and the rampart walkway), eased toward the target so steps and
 *   slopes don't snap the camera.
 * - Colliders are skipped when the player box has no vertical overlap with
 *   them (lets us stand on top of the rampart walkway without the wall
 *   segments below shoving us sideways; railings still block).
 */

const EYE_HEIGHT = 1.65;
const PLAYER_W = 0.55;          // width (x/z)
const PLAYER_H = 1.7;           // height
const WALK_SPEED = 3.2;
const SPRINT_SPEED = 5.2;
// Exponential velocity convergence rate (1/s). ~9 gives a ~0.35s settle to target:
// snappy on start, no slide at the end, no oscillation. Critically-damped feel.
const MOVE_RESPONSE = 9.0;
// Feet converge to the ground height this fast (1/s); fast enough for the
// ramp, soft enough to ride terrain bumps without judder.
const GROUND_RESPONSE = 12.0;
// Max axis displacement allowed per physics sub-step. Well below the thinnest
// wall (0.3m) and the player's own half-width, so tunneling is impossible.
const MAX_STEP = 0.15;
const PITCH_LIMIT = 1.5;        // radians
const SENSITIVITY = 0.0023;

export class Player {
  /**
   * @param {THREE.Camera} camera
   * @param {HTMLElement} domElement - element to request pointer lock on
   * @param {() => THREE.Box3[]} getColliders - returns the live collider array
   * @param {(x: number, z: number) => number} groundHeight - walkable height
   */
  constructor(camera, domElement, getColliders, groundHeight) {
    this.camera = camera;
    this.domElement = domElement;
    this.getColliders = getColliders;
    this.groundHeight = groundHeight || (() => 0);

    this.locked = false;
    this.yaw = 0;
    this.pitch = 0;

    // World-space state. Player AABB: center = (pos.x, pos.y + PLAYER_H/2, pos.z),
    // pos.y is foot height (rides the ground).
    this.pos = new THREE.Vector3(0, 0, 95);
    this.vel = new THREE.Vector3(); // x/z velocity, y unused

    this.keys = new Set();

    this._euler = new THREE.Euler(0, 0, 0, 'YXZ');
    this._box = new THREE.Box3();
    this._forward = new THREE.Vector3();
    this._right = new THREE.Vector3();
    this._targetVel = new THREE.Vector3();

    this._onMouseMove = (e) => {
      if (!this.locked) return;
      this.yaw -= e.movementX * SENSITIVITY;
      this.pitch -= e.movementY * SENSITIVITY;
      this.pitch = THREE.MathUtils.clamp(this.pitch, -PITCH_LIMIT, PITCH_LIMIT);
      this._applyLook();
    };

    this._onKeyDown = (e) => {
      if (e.repeat) return;
      this.keys.add(e.code);
    };
    this._onKeyUp = (e) => {
      this.keys.delete(e.code);
    };

    this._onLockChange = () => {
      const was = this.locked;
      this.locked = document.pointerLockElement === this.domElement;
      // Graceful unlock: stop all motion so the player never drifts or keeps
      // walking while the cursor is free. Key states are re-captured on lock.
      if (was && !this.locked) this.keys.clear();
    };

    document.addEventListener('mousemove', this._onMouseMove);
    document.addEventListener('keydown', this._onKeyDown);
    document.addEventListener('keyup', this._onKeyUp);
    document.addEventListener('pointerlockchange', this._onLockChange);
  }

  requestLock() {
    if (document.pointerLockElement !== this.domElement) {
      try {
        const p = this.domElement.requestPointerLock();
        if (p && p.catch) p.catch(() => {});
      } catch (e) { /* pointer lock unavailable */ }
    }
  }

  /** Instantly place the player (scripted walkthroughs). Keeps velocity zeroed. */
  teleport(pos, yaw) {
    this.pos.set(pos.x, this.groundHeight(pos.x, pos.z), pos.z);
    if (yaw !== undefined) {
      this.yaw = yaw;
      this._applyLook();
    }
    this.vel.set(0, 0, 0);
  }

  getPosition() {
    return new THREE.Vector3(this.pos.x, this.pos.y + EYE_HEIGHT, this.pos.z);
  }

  _applyLook() {
    this._euler.set(this.pitch, this.yaw, 0);
    this.camera.quaternion.setFromEuler(this._euler);
  }

  /** Build the player AABB at a given x/z and foot height into this._box. */
  _playerBoxAt(x, y, z, out) {
    const hx = PLAYER_W / 2;
    out.min.set(x - hx, y, z - hx);
    out.max.set(x + hx, y + PLAYER_H, z + hx);
    return out;
  }

  /** Push the box out of a collider along a single axis; returns corrected value. */
  _resolveAxis(collider, axis /* 'x'|'z' */) {
    const b = this._box;
    if (!b.intersectsBox(collider)) return null;
    const pMin = axis === 'x' ? b.min.x : b.min.z;
    const pMax = axis === 'x' ? b.max.x : b.max.z;
    const cMin = axis === 'x' ? collider.min.x : collider.min.z;
    const cMax = axis === 'x' ? collider.max.x : collider.max.z;
    const pCenter = (pMin + pMax) / 2;
    const cCenter = (cMin + cMax) / 2;
    // Push out along the smallest penetration direction.
    if (pCenter < cCenter) {
      return cMin - (pMax - pMin) / 2; // player min side exits at collider min
    }
    return cMax + (pMax - pMin) / 2;
  }

  _collideAxis(axis) {
    const colliders = this.getColliders();
    if (!colliders || colliders.length === 0) return;
    this._playerBoxAt(this.pos.x, this.pos.y, this.pos.z, this._box);
    const feet = this._box.min.y, head = this._box.max.y;
    for (let i = 0; i < colliders.length; i++) {
      const c = colliders[i];
      // Vertical overlap gate: standing on top of something (rampart walkway
      // over the wall segments below it) must not shove us sideways; a
      // collider entirely above our head is likewise irrelevant. A small
      // tolerance keeps us from catching on the exact stand plane.
      if (c.max.y <= feet + 0.05) continue;
      if (c.min.y >= head - 0.05) continue;
      const corrected = this._resolveAxis(c, axis);
      if (corrected !== null) {
        if (axis === 'x') { this.pos.x = corrected; this._playerBoxAt(this.pos.x, this.pos.y, this.pos.z, this._box); }
        else { this.pos.z = corrected; this._playerBoxAt(this.pos.x, this.pos.y, this.pos.z, this._box); }
      }
    }
  }

  update(dt) {
    // Clamp dt so a hitch never becomes a teleport.
    dt = Math.min(dt, 0.05);

    // --- Look-independent movement input ---
    let ix = 0, iz = 0;
    const k = this.keys;
    if (this.locked) {
      if (k.has('KeyW') || k.has('ArrowUp')) iz -= 1;
      if (k.has('KeyS') || k.has('ArrowDown')) iz += 1;
      if (k.has('KeyA') || k.has('ArrowLeft')) ix -= 1;
      if (k.has('KeyD') || k.has('ArrowRight')) ix += 1;
    }

    const sprinting = k.has('ShiftLeft') || k.has('ShiftRight');
    const speed = sprinting ? SPRINT_SPEED : WALK_SPEED;

    // Camera-relative basis on the floor plane.
    this._euler.set(0, this.yaw, 0);
    this._forward.set(0, 0, -1).applyEuler(this._euler);
    this._right.set(1, 0, 0).applyEuler(this._euler);

    this._targetVel.set(0, 0, 0)
      .addScaledVector(this._forward, -iz)
      .addScaledVector(this._right, ix);
    if (this._targetVel.lengthSq() > 0) {
      this._targetVel.normalize().multiplyScalar(speed);
    }

    // Exponential approach: fast attack, no overshoot — critically damped feel.
    const a = 1 - Math.exp(-MOVE_RESPONSE * dt);
    this.vel.x += (this._targetVel.x - this.vel.x) * a;
    this.vel.z += (this._targetVel.z - this.vel.z) * a;

    // --- Integrate with axis separation + sub-stepping (anti-tunnel) ---
    const totalDx = this.vel.x * dt;
    const totalDz = this.vel.z * dt;
    const steps = Math.max(
      1,
      Math.ceil(Math.abs(totalDx) / MAX_STEP),
      Math.ceil(Math.abs(totalDz) / MAX_STEP)
    );
    for (let s = 0; s < steps; s++) {
      this.pos.x += totalDx / steps;
      this._collideAxis('x');
      this.pos.z += totalDz / steps;
      this._collideAxis('z');
    }

    // --- Ride the ground (terrain, ramp, walkway) ---
    const gh = this.groundHeight(this.pos.x, this.pos.z);
    const ga = 1 - Math.exp(-GROUND_RESPONSE * dt);
    this.pos.y += (gh - this.pos.y) * ga;

    // --- Write to camera ---
    this.camera.position.set(this.pos.x, this.pos.y + EYE_HEIGHT, this.pos.z);
    this._applyLook();
  }

  dispose() {
    document.removeEventListener('mousemove', this._onMouseMove);
    document.removeEventListener('keydown', this._onKeyDown);
    document.removeEventListener('keyup', this._onKeyUp);
    document.removeEventListener('pointerlockchange', this._onLockChange);
  }
}
